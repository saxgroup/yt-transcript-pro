// background.js - v6.17 (Worker Window Logic for Batch)

const DEFAULT_NAME_TEMPLATE = "[{channel}] {title} ({date}) [{lang}]";

// --- HELPER: Costruzione Nome File ---
function buildFilenameFromTemplate(tpl, meta, format) {
  const safe = (v) => sanitizeFilename(v || "");
  const date = meta?.publishDate || new Date().toISOString().slice(0, 10);
  const lang = meta?.language || "";
  
  const map = {
    "{title}": safe(meta?.title),
    "{channel}": safe(meta?.channel),
    "{date}": safe(date),
    "{lang}": safe(lang === "dom" ? "" : lang),
    "{videoId}": safe(meta?.videoId),
    "{format}": safe(format),
    "{tag}": safe(meta?.tag || "")
  };

  let name = tpl;
  for (const k in map) name = name.replaceAll(k, map[k]);
  
  return name.replace(/\[\s*\]/g, "").replace(/\(\s*\)/g, "").replace(/\s{2,}/g, " ").trim();
}

function sanitizeFilename(name) {
  return (name || "transcript").replace(/[\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 180);
}

// --- HELPER: Iniezione Script ---
async function ensureContent(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  } catch (e) { 
    // Ignora errori su pagine non permesse
  }
}

// --- HELPER: Download ---
async function downloadTextFile({ filename, text, mime }) {
  const url = `data:${mime || "text/plain"};charset=utf-8,${encodeURIComponent(text)}`;
  await chrome.downloads.download({ url, filename, saveAs: false });
}

// --- HELPER: Attesa Caricamento Tab (Robust) ---
function waitForTabLoad(tabId) {
  return new Promise((resolve) => {
    const listener = (tid, changeInfo) => {
      if (tid === tabId && changeInfo.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        // Pausa extra per permettere a YouTube di inizializzare gli script (API Response)
        setTimeout(resolve, 2500); 
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// --- MAIN LISTENER ---
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      
      // 1. DOWNLOAD VIDEO SINGOLO
      if (msg.type === "DOWNLOAD_ONE") {
        const { tabId, format, lang } = msg;
        await ensureContent(tabId);
        
        const resp = await chrome.tabs.sendMessage(tabId, { type: "BUILD_TRANSCRIPT_FOR_CURRENT", format, lang });
        
        if (!resp?.ok) { 
          sendResponse({ ok: false, error: resp?.error || "Errore generico" }); 
          return; 
        }

        const tpl = msg.naming?.template || DEFAULT_NAME_TEMPLATE;
        resp.meta.tag = msg.naming?.tag || "";
        const base = buildFilenameFromTemplate(tpl, resp.meta, format);
        const ext = format === "srt" ? "srt" : format === "json" ? "json" : "txt";
        
        await downloadTextFile({ 
          filename: `${base}.${ext}`, 
          text: resp.text, 
          mime: format === "json" ? "application/json" : "text/plain" 
        });
        
        sendResponse({ ok: true, filename: `${base}.${ext}` });
      }

      // 2. DOWNLOAD PLAYLIST (WORKER WINDOW STRATEGY)
      else if (msg.type === "DOWNLOAD_PLAYLIST") {
        const { tabId, format, lang, naming } = msg;
        await ensureContent(tabId);
        
        // Ottieni lista ID dalla pagina playlist corrente
        const idsResp = await chrome.tabs.sendMessage(tabId, { type: "GET_PLAYLIST_VIDEO_IDS" });
        if (!idsResp?.ok) { sendResponse({ ok: false, error: idsResp?.error }); return; }
        
        const videoIds = [...new Set(idsResp.videoIds || [])].filter(Boolean);
        let done = 0, skipped = 0, failed = 0;
        const tpl = naming?.template || DEFAULT_NAME_TEMPLATE;
        const tag = naming?.tag || "";

        // A. Crea una "Worker Window" dedicata
        // Usiamo una finestra popup separata per garantire che Chrome dia priorità al caricamento
        // ma riutilizziamo la stessa finestra per tutti i video per non intasare il PC.
        let workerWindow = null;
        try {
          workerWindow = await chrome.windows.create({ 
            url: "about:blank", 
            type: "popup", 
            width: 600, 
            height: 600,
            focused: true // Fondamentale: se non è focused, YouTube non carica i dati
          });
        } catch (e) {
          sendResponse({ ok: false, error: "Impossibile aprire finestra di lavoro." });
          return;
        }

        const workerTabId = workerWindow.tabs[0].id;

        // B. Itera sui video riutilizzando la stessa tab
        for (const vid of videoIds) {
          try {
            // Naviga al video
            await chrome.tabs.update(workerTabId, { url: `https://www.youtube.com/watch?v=${vid}` });
            
            // Attendi caricamento completo
            await waitForTabLoad(workerTabId);
            await ensureContent(workerTabId);
            
            // Estrai trascrizione
            const built = await chrome.tabs.sendMessage(workerTabId, { type: "BUILD_TRANSCRIPT_FOR_CURRENT", format, lang });
            
            if (!built?.ok) { 
              built?.skipped ? skipped++ : failed++; 
            } else {
              // Salva file
              built.meta.tag = tag;
              const base = buildFilenameFromTemplate(tpl, built.meta, format);
              const ext = format === "srt" ? "srt" : format === "json" ? "json" : "txt";
              
              await downloadTextFile({ 
                filename: `Playlist/${base}.${ext}`, 
                text: built.text, 
                mime: format === "json" ? "application/json" : "text/plain" 
              });
              
              done++;
            }
          } catch (e) { 
            failed++; 
            console.error("Errore playlist video:", vid, e);
            // Se la finestra è stata chiusa dall'utente, interrompi tutto
            try { await chrome.tabs.get(workerTabId); } catch { break; }
          }
        }
        
        // C. Chiudi la finestra worker alla fine
        if (workerWindow) {
          try { await chrome.windows.remove(workerWindow.id); } catch {}
        }
        
        sendResponse({ ok: true, done, skipped, failed, total: videoIds.length });
      }

    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
  })();
  
  return true; // Indica risposta asincrona
});