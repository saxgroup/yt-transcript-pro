// content.js - VERSIONE COMPLETA (API + DOM con SRT/JSON)

(() => {
  if (globalThis.__YT_TRANSCRIPT_PRO__?.injected) return;
  globalThis.__YT_TRANSCRIPT_PRO__ = globalThis.__YT_TRANSCRIPT_PRO__ || {};
  globalThis.__YT_TRANSCRIPT_PRO__.injected = true;

  // --- UTILS ---
  function sanitizeText(s) {
    return (s || "").replace(/\u00a0/g, " ").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  function getVideoIdFromUrl(urlStr) {
    try { return new URL(urlStr || location.href).searchParams.get("v"); } catch { return null; }
  }

  function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

  // --- TIME HELPERS (Per SRT da DOM) ---
  function msToSrtTime(ms) {
    const total = Math.max(0, Number(ms) || 0);
    const h = Math.floor(total / 3600000);
    const m = Math.floor((total % 3600000) / 60000);
    const s = Math.floor((total % 60000) / 1000);
    const msRem = Math.floor(total % 1000);
    const pad = (n, len = 2) => String(n).padStart(len, "0");
    return `${pad(h)}:${pad(m)}:${pad(s)},${pad(msRem, 3)}`;
  }

  function timestampToMs(ts) {
    // Converte "1:05" o "1:02:30" in millisecondi
    if (!ts) return 0;
    const parts = ts.split(":").map(Number);
    let s = 0;
    if (parts.length === 3) s = parts[0] * 3600 + parts[1] * 60 + parts[2];
    else if (parts.length === 2) s = parts[0] * 60 + parts[1];
    else s = parts[0];
    return s * 1000;
  }

  // --- API LOGIC ---
  function getCaptionTracks() {
    const pr = window.ytInitialPlayerResponse;
    if (pr?.videoDetails?.videoId !== getVideoIdFromUrl(location.href)) return [];
    const tracks = pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
    return Array.isArray(tracks) ? tracks.map(t => ({
      languageCode: t.languageCode,
      label: t.name?.simpleText || t.languageCode,
      kind: t.kind || "manual",
      baseUrl: t.baseUrl
    })) : [];
  }

  async function fetchTimedText(baseUrl) {
    if (!baseUrl) return null;
    try {
      const u = new URL(baseUrl);
      u.searchParams.set("fmt", "json3");
      const res = await fetch(u.toString());
      if (!res.ok) return null;
      const data = await res.json();
      return data?.events?.length ? data : null;
    } catch { return null; }
  }

  function eventsToTXT(events) {
    return (events || []).map(e => e.segs ? sanitizeText(e.segs.map(s => s.utf8).join("")) : "").filter(Boolean).join("\n");
  }

  function eventsToSRT(events) {
    let idx = 1;
    const out = [];
    for (const e of events || []) {
      if (!e?.segs) continue;
      const text = sanitizeText(e.segs.map(s => s.utf8 || "").join(""));
      if (!text) continue;
      const start = msToSrtTime(e.tStartMs);
      const end = msToSrtTime((e.tStartMs || 0) + (e.dDurationMs || 0));
      out.push(String(idx++));
      out.push(`${start} --> ${end}`);
      out.push(text);
      out.push("");
    }
    return out.join("\n");
  }

  // --- DOM PARSING LOGIC (SRT/JSON Support) ---
  
  function getDomSegments() {
    // Estrae { time: "1:00", text: "Ciao" } dal DOM
    const nodes = document.querySelectorAll("ytd-transcript-segment-renderer");
    if (!nodes.length) return [];
    
    const segments = [];
    nodes.forEach(node => {
      const timeEl = node.querySelector(".segment-timestamp") || node.querySelector("#segment-timestamp");
      const textEl = node.querySelector(".segment-text") || node.querySelector("#segment-text");
      
      const timeStr = (timeEl?.innerText || "").trim();
      const text = sanitizeText(textEl?.innerText || "");
      
      if (text) segments.push({ timeStr, text });
    });
    return segments;
  }

  function domToSRT(segments) {
    let idx = 1;
    const out = [];
    for (let i = 0; i < segments.length; i++) {
      const cur = segments[i];
      const next = segments[i+1];
      
      const startMs = timestampToMs(cur.timeStr);
      // Se non c'è un segmento successivo, aggiungiamo 2 secondi arbitrari
      const endMs = next ? timestampToMs(next.timeStr) : (startMs + 2000);
      
      out.push(String(idx++));
      out.push(`${msToSrtTime(startMs)} --> ${msToSrtTime(endMs)}`);
      out.push(cur.text);
      out.push("");
    }
    return out.join("\n");
  }

  // --- DOM AUTO-OPEN ---
  function isTranscriptLoaded() {
    return document.querySelectorAll("ytd-transcript-segment-renderer").length > 0;
  }

  function clickElement(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: "center" }); } catch {}
    el.click();
    return true;
  }

  function findButtonByText(regex) {
    const selectors = "button, tp-yt-paper-button, ytd-menu-service-item-renderer, div.item";
    const elements = document.querySelectorAll(selectors);
    for (const el of elements) {
      if (el.offsetParent === null) continue; 
      const t = (el.innerText || el.textContent || "").trim();
      if (regex.test(t)) return el;
    }
    return null;
  }

  async function tryOpenTranscriptPanel() {
    if (isTranscriptLoaded()) return true;

    const directBtn = 
      document.querySelector('button[aria-label*="transcript" i]') || 
      document.querySelector('button[aria-label*="trascrizione" i]') ||
      findButtonByText(/^(mostra trascrizione|show transcript|trascrizione|transcript)$/i);

    if (clickElement(directBtn)) {
      await sleep(800);
      if (isTranscriptLoaded()) return true;
    }

    const moreBtn = document.querySelector('button[aria-label="More actions"]') || 
                    document.querySelector('button[aria-label="Altre azioni"]') ||
                    document.querySelector('#menu-button button');
    
    if (clickElement(moreBtn)) {
      await sleep(400);
      const menuBtn = findButtonByText(/^(mostra trascrizione|show transcript|trascrizione|transcript)$/i);
      if (clickElement(menuBtn)) {
        await sleep(800);
        if (isTranscriptLoaded()) return true;
      }
      document.body.click(); 
    }
    
    // Fallback descrizione espansa
    const expandBtn = document.querySelector('#expand');
    if (clickElement(expandBtn)) {
        await sleep(300);
        const descBtn = findButtonByText(/^(mostra trascrizione|show transcript)$/i);
        if (clickElement(descBtn)) {
            await sleep(800);
            return isTranscriptLoaded();
        }
    }

    return false;
  }

  // --- MAIN BUILDER ---
  async function buildTranscript({ videoId, format, lang }) {
    if (!videoId) return { ok: false, error: "Video ID mancante" };

    const meta = {
      videoId,
      title: document.title.replace("- YouTube", "").trim(),
      channel: document.querySelector("#owner #channel-name a")?.textContent?.trim() || "",
      publishDate: null
    };

    // 1. TENTATIVO API
    const tracks = getCaptionTracks();
    if (tracks.length > 0) {
      let bestTrack = null;
      if (lang === "auto") {
        const browser = (navigator.language || "en").split("-")[0];
        bestTrack = tracks.find(t => t.languageCode === browser && t.kind !== "asr") || 
                    tracks.find(t => t.kind !== "asr") || 
                    tracks[0];
      } else {
        bestTrack = tracks.find(t => t.languageCode === lang);
      }

      if (bestTrack) {
        const data = await fetchTimedText(bestTrack.baseUrl);
        if (data) {
          let text = "";
          if (format === "srt") text = eventsToSRT(data.events);
          else if (format === "json") text = JSON.stringify({ meta: { ...meta, language: bestTrack.languageCode }, transcript: data }, null, 2);
          else text = eventsToTXT(data.events);

          return { ok: true, text, meta: { ...meta, language: bestTrack.languageCode } };
        }
      }
    }

    // 2. TENTATIVO DOM (Fallback)
    const opened = await tryOpenTranscriptPanel();
    
    if (opened || isTranscriptLoaded()) {
      const segments = getDomSegments();
      
      if (segments.length > 0) {
        let text = "";
        if (format === "srt") {
          text = domToSRT(segments);
        } else if (format === "json") {
          text = JSON.stringify({ 
            meta: { ...meta, language: "dom", source: "panel" }, 
            transcript: segments 
          }, null, 2);
        } else {
          // TXT
          text = segments.map(s => s.text).join("\n");
        }

        return { ok: true, text, meta: { ...meta, language: "dom" } };
      }
    }

    return { ok: false, error: "Trascrizione non disponibile." };
  }

  // --- MESSAGING ---
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
      try {
        if (msg.type === "GET_LANGS") {
          sendResponse({ ok: true, langs: getCaptionTracks() });
        } 
        else if (msg.type === "BUILD_TRANSCRIPT_FOR_CURRENT") {
          const vid = getVideoIdFromUrl(location.href);
          const res = await buildTranscript({ videoId: vid, format: msg.format, lang: msg.lang });
          sendResponse(res);
        }
        else if (msg.type === "GET_PLAYLIST_VIDEO_IDS") {
            const ids = new Set();
            document.querySelectorAll('ytd-playlist-panel-video-renderer a#wc-endpoint').forEach(a => {
                const v = new URL(a.href, location.origin).searchParams.get("v");
                if (v) ids.add(v);
            });
            sendResponse({ ok: true, videoIds: Array.from(ids) });
        }
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true;
  });

})();