// FILE: popup.js

const $ = (id) => document.getElementById(id);

// --- CONSTANTS ---
const SYNC_KEYS = { 
  THEME: "themePref", 
  TPL: "nameTemplate", 
  TAG: "nameTag", 
  PRESET: "namePreset", 
  AI_KEY: "geminiApiKey", 
  AI_MODEL: "geminiModel",
  TTS_RATE: "ttsRate" // Nuova chiave per la velocità voce
};

const LOCAL_KEYS = { 
  HISTORY: "videoHistory", 
  DETACH_STATE: "detachState" 
};

const PRESETS = { 
  archive: "[{tag}] [{channel}] {title} ({date}) [{lang}]", 
  minimal: "{title} ({date})", 
  tech: "[{tag}] [{channel}] {title} ({date}) [{lang}] [{videoId}]" 
};

// Variabili Globali
window.currentTranscript = null;
window.currentMeta = null;

// --- STORAGE HELPERS ---
async function getSettings(keys) { 
  const s = await chrome.storage.sync.get(keys); 
  const l = await chrome.storage.local.get(keys); 
  return { ...l, ...s }; 
}
async function saveSetting(key, value) { 
  await chrome.storage.sync.set({ [key]: value }); 
}

// --- INIT ---
document.addEventListener("DOMContentLoaded", async () => {
  await initTheme();
  initTabs();
  initNaming();
  initDownloadLogic();
  initAiLogic();
  
  // Gestione Distacco
  $("btnDetach").addEventListener("click", detachWindow);
  
  // Check modalità distaccata
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has("tabId")) {
    $("btnDetach").style.display = "none";
    document.body.style.width = "100%";
    document.body.style.height = "100vh";
    document.querySelector(".wrap").style.width = "auto";
    
    // RIPRISTINO STATO (FIX PERDITA DATI)
    await restoreStateIfDetached();
  } else {
    // Solo se NON siamo distaccati proviamo a caricare la storia automatica
    setTimeout(checkHistoryForCurrentVideo, 500);
  }
});

// --- WINDOW DETACH LOGIC ---
async function detachWindow() {
  const tabId = await getActiveTabId();
  if (!tabId) return;

  // 1. Salva lo stato corrente
  const state = {
    output: $("aiOutput").value,
    metaTitle: $("aiOutput").dataset.metaTitle,
    model: $("aiModel").value,
    promptType: $("aiPromptType").value,
    customPrompt: $("customPromptText").value,
    transcript: window.currentTranscript,
    meta: window.currentMeta,
    chatHtml: $("chatHistory").innerHTML,
    isChatVisible: $("chatSection").style.display === "block",
    ttsRate: $("ttsRate").value // Salva anche la velocità corrente
  };

  await chrome.storage.local.set({ [LOCAL_KEYS.DETACH_STATE]: state });

  // 2. Apri nuova finestra
  chrome.windows.create({
    url: `popup.html?tabId=${tabId}`,
    type: "popup",
    width: 450,
    height: 700
  });
  
  window.close();
}

async function restoreStateIfDetached() {
  const stored = await chrome.storage.local.get([LOCAL_KEYS.DETACH_STATE]);
  const state = stored[LOCAL_KEYS.DETACH_STATE];
  
  if (state) {
    // Ripristina UI
    $("aiOutput").value = state.output || "";
    if(state.metaTitle) $("aiOutput").dataset.metaTitle = state.metaTitle;
    
    $("aiModel").value = state.model;
    $("aiPromptType").value = state.promptType;
    $("customPromptText").value = state.customPrompt || "";
    if(state.ttsRate) $("ttsRate").value = state.ttsRate;
    
    if (state.promptType === "custom") $("customPromptWrap").style.display = "block";
    
    // Ripristina Variabili Globali
    window.currentTranscript = state.transcript;
    window.currentMeta = state.meta;
    
    // Ripristina Chat
    if (state.chatHtml) $("chatHistory").innerHTML = state.chatHtml;
    if (state.isChatVisible) {
      $("chatSection").style.display = "block";
      $("chatInput").disabled = false;
      $("btnChatSend").disabled = false;
    }
    
    // Check Mermaid
    checkMermaid(state.output || "");
    
    // Attiva Tab AI
    document.querySelector('[data-target="tab-ai"]').click();

    // Pulisci lo stato salvato
    await chrome.storage.local.remove(LOCAL_KEYS.DETACH_STATE);
  }
}

// --- TAB ID LOGIC ---
async function getActiveTabId() {
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has("tabId")) return parseInt(urlParams.get("tabId"), 10);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id;
}

// --- THEME (3-WAY TOGGLE) ---
async function initTheme() {
  const stored = await getSettings([SYNC_KEYS.THEME]);
  const pref = stored[SYNC_KEYS.THEME] || "auto";
  applyTheme(pref);
  
  $("themeSwitch").addEventListener("click", async () => {
    const current = document.body.getAttribute("data-theme");
    let next = "dark";
    if (current === "dark") next = "light";
    else if (current === "light") next = "contrast";
    else next = "dark"; 
    
    await saveSetting(SYNC_KEYS.THEME, next);
    applyTheme(next);
  });
}

function applyTheme(pref) {
  let mode = pref;
  if (pref === "auto") mode = (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) ? "dark" : "light";
  document.body.setAttribute("data-theme", mode);
  
  const icon = $("themeSwitch").querySelector("span");
  if (mode === "dark") icon.textContent = "🌙";
  else if (mode === "light") icon.textContent = "☀️";
  else icon.textContent = "🚧"; 
}

// --- TABS, NAMING, DOWNLOAD ---
function initTabs() {
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
      btn.classList.add("active");
      $(btn.dataset.target).classList.add("active");
    });
  });
}
async function initNaming() {
  const stored = await getSettings([SYNC_KEYS.TPL, SYNC_KEYS.TAG, SYNC_KEYS.PRESET]);
  const preset = stored[SYNC_KEYS.PRESET] || "archive";
  $("preset").value = preset;
  $("tag").value = stored[SYNC_KEYS.TAG] || "";
  updateTemplateState(preset, stored[SYNC_KEYS.TPL]);
  renderPreview();
  $("preset").addEventListener("change", (e) => { updateTemplateState(e.target.value); saveNaming(); });
  $("tag").addEventListener("input", () => { saveNaming(); renderPreview(); });
  $("template").addEventListener("input", () => { saveNaming(); renderPreview(); });
  $("format").addEventListener("change", renderPreview);
}
function updateTemplateState(preset, savedTpl) {
  const tplEl = $("template");
  if (preset !== "custom") { tplEl.value = PRESETS[preset] || PRESETS.archive; tplEl.disabled = true; } 
  else { tplEl.disabled = false; if (savedTpl) tplEl.value = savedTpl; }
  renderPreview();
}
async function saveNaming() {
  await saveSetting(SYNC_KEYS.PRESET, $("preset").value);
  await saveSetting(SYNC_KEYS.TAG, $("tag").value);
  await saveSetting(SYNC_KEYS.TPL, $("template").value);
  renderPreview();
}
function renderPreview() {
  const tpl = $("template").value;
  let s = tpl.replace("{title}", "Video Title").replace("{channel}", "Channel Name").replace("{date}", "2025-01-01").replace("{lang}", "IT").replace("{videoId}", "ABC123xyz").replace("{format}", $("format").value).replace("{tag}", $("tag").value);
  $("namePreview").textContent = s.replace(/\[\s*\]/g, "").replace(/\(\s*\)/g, "").replace(/\s{2,}/g, " ").trim();
}
async function initDownloadLogic() {
  loadLanguages();
  $("downloadOne").addEventListener("click", () => runDownload("one"));
  $("downloadPlaylist").addEventListener("click", () => runDownload("playlist"));
}
async function loadLanguages() {
  const tabId = await getActiveTabId();
  if (!tabId) return;
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }).catch(() => {});
  try {
    const resp = await chrome.tabs.sendMessage(tabId, { type: "GET_LANGS" });
    const sel = $("lang");
    sel.innerHTML = `<option value="auto">Auto (consigliato)</option>`;
    if (resp && resp.langs) {
      resp.langs.forEach(l => {
        const opt = document.createElement("option");
        opt.value = l.languageCode;
        opt.textContent = `${l.label} ${l.kind === 'asr' ? '(Auto)' : ''}`;
        sel.appendChild(opt);
      });
      $("langHint").textContent = `Rilevate ${resp.langs.length} lingue.`;
    }
  } catch(e) { $("langHint").textContent = "Nessuna lingua rilevata."; }
}
async function runDownload(mode) {
  const btn = mode === "playlist" ? $("downloadPlaylist") : $("downloadOne");
  setBusy(btn, true);
  setStatus("Inizio download...");
  try {
    const tabId = await getActiveTabId();
    const naming = { template: $("template").value, tag: $("tag").value };
    if (mode === "playlist") { $("progressWrap").style.display = "block"; $("progressFill").style.width = "0%"; }
    const resp = await chrome.runtime.sendMessage({ type: mode === "playlist" ? "DOWNLOAD_PLAYLIST" : "DOWNLOAD_ONE", tabId, format: $("format").value, lang: $("lang").value, naming });
    if (!resp.ok) throw new Error(resp.error);
    setStatus(mode === "playlist" ? `Finito. Scaricati: ${resp.done}, Errori: ${resp.failed}` : `Salvato: ${resp.filename}`);
  } catch (e) { setStatus(`Errore: ${e.message}`); } finally { setBusy(btn, false); if(mode === "playlist") $("progressWrap").style.display = "none"; }
}
function setBusy(btn, isBusy) { btn.disabled = isBusy; btn.classList.toggle("is-loading", isBusy); }
function setStatus(msg) { $("status").textContent = msg; }

/* =================================================================
   AI GEMINI LOGIC (STREAMING + SYNC + TTS)
   ================================================================= */

async function initAiLogic() {
  // Carica impostazioni (inclusa velocità TTS)
  const stored = await getSettings([SYNC_KEYS.AI_KEY, SYNC_KEYS.AI_MODEL, SYNC_KEYS.TTS_RATE]);
  
  if (stored[SYNC_KEYS.AI_KEY]) $("apiKey").value = stored[SYNC_KEYS.AI_KEY];
  if (stored[SYNC_KEYS.AI_MODEL]) $("aiModel").value = stored[SYNC_KEYS.AI_MODEL];
  if (stored[SYNC_KEYS.TTS_RATE]) $("ttsRate").value = stored[SYNC_KEYS.TTS_RATE];

  // Listeners Salvataggio
  $("apiKey").addEventListener("change", (e) => saveSetting(SYNC_KEYS.AI_KEY, e.target.value.trim()));
  $("aiModel").addEventListener("change", (e) => saveSetting(SYNC_KEYS.AI_MODEL, e.target.value));
  
  // Listener Velocità TTS
  $("ttsRate").addEventListener("change", (e) => {
    saveSetting(SYNC_KEYS.TTS_RATE, e.target.value);
    // Se sta parlando, ferma per applicare la nuova velocità al prossimo click
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      $("btnAiTTS").textContent = "🔊 Ascolta";
    }
  });

  $("aiPromptType").addEventListener("change", (e) => {
    $("customPromptWrap").style.display = e.target.value === "custom" ? "block" : "none";
  });

  $("btnAiGenerate").addEventListener("click", runAiSummary);
  
  // TTS Listener
  $("btnAiTTS").addEventListener("click", toggleTTS);

  $("btnAiCopy").addEventListener("click", () => {
    const txt = $("aiOutput").value; if(!txt) return;
    navigator.clipboard.writeText(txt);
    $("btnAiCopy").textContent = "Copiato!";
    setTimeout(() => $("btnAiCopy").textContent = "Copia", 1500);
  });
  $("btnAiSaveTxt").addEventListener("click", saveAiCleanTxt);
  $("btnAiSaveMd").addEventListener("click", saveAiTelegramMd);
  $("btnAiSaveHtml").addEventListener("click", saveAiHtml);
  $("btnAiViewMermaid").addEventListener("click", openMermaidLive);
  $("btnChatSend").addEventListener("click", runChat);
  $("chatInput").addEventListener("keypress", (e) => { if(e.key === "Enter") runChat(); });
}

// --- HISTORY ---
async function checkHistoryForCurrentVideo() {
  try {
    const tabId = await getActiveTabId();
  } catch {}
}

async function saveHistory(videoId, text, transcript, meta) {
  const stored = await chrome.storage.local.get([LOCAL_KEYS.HISTORY]);
  const history = stored[LOCAL_KEYS.HISTORY] || {};
  history[videoId] = { text, transcript, meta, date: Date.now() };
  const keys = Object.keys(history);
  if (keys.length > 10) delete history[keys[0]];
  await chrome.storage.local.set({ [LOCAL_KEYS.HISTORY]: history });
}

async function loadHistory(videoId) {
  const stored = await chrome.storage.local.get([LOCAL_KEYS.HISTORY]);
  const entry = stored[LOCAL_KEYS.HISTORY]?.[videoId];
  if (entry) {
    $("aiOutput").value = entry.text;
    $("aiOutput").dataset.metaTitle = entry.meta.title;
    window.currentTranscript = entry.transcript;
    window.currentMeta = entry.meta;
    $("historyBadge").style.display = "inline-block";
    enableChat();
    checkMermaid(entry.text);
    return true;
  }
  return false;
}

// --- MAIN GENERATION (STREAMING) ---
async function runAiSummary() {
  // Safety Stop TTS
  if (window.speechSynthesis.speaking) {
    window.speechSynthesis.cancel();
    $("btnAiTTS").textContent = "🔊 Ascolta";
  }

  const apiKey = $("apiKey").value.trim();
  if (!apiKey) { alert("Inserisci la Google API Key."); return; }

  const btn = $("btnAiGenerate");
  const output = $("aiOutput");
  
  setBusy(btn, true);
  output.value = ""; 
  output.placeholder = "🤖 Gemini sta scrivendo...";
  $("historyBadge").style.display = "none";
  $("btnAiViewMermaid").style.display = "none";
  
  try {
    const tabId = await getActiveTabId();
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }).catch(() => {});

    const resp = await chrome.tabs.sendMessage(tabId, { type: "BUILD_TRANSCRIPT_FOR_CURRENT", format: "txt", lang: $("lang").value });
    if (!resp?.ok) throw new Error(resp?.error || "Errore trascrizione.");
    
    const transcriptText = resp.text;
    if (transcriptText.length < 50) throw new Error("Trascrizione troppo breve.");

    window.currentTranscript = transcriptText;
    window.currentMeta = resp.meta;

    const promptType = $("aiPromptType").value;
    const model = $("aiModel").value.trim(); 
    
    let systemPrompt = "";
    switch(promptType) {
      case "bullet": systemPrompt = "Crea una lista puntata dettagliata dei concetti chiave. Usa emoji."; break;
      case "deep": systemPrompt = "Agisci come esperto tecnico. Analisi approfondita, stack tecnologico, metodologia."; break;
      case "fact": systemPrompt = "Fact Checking. Identifica errori, contraddizioni e affermazioni controverse."; break;
      case "tweet": systemPrompt = "Crea un thread per Twitter/X. Frasi brevi, max 280 caratteri per tweet."; break;
      case "mermaid": systemPrompt = `Crea una Mappa Mentale usando la sintassi Mermaid.js. Restituisci SOLO il codice markdown \`\`\`mermaid ... \`\`\`.`; break;
      case "custom": systemPrompt = $("customPromptText").value; if(!systemPrompt) throw new Error("Inserisci il prompt."); break;
      default: systemPrompt = `Fornisci un Riassunto Esecutivo chiaro e conciso. Usa titoli e paragrafi. Stile leggibile, visivamente ordinato con: 📋 Titolo, 📌 Intro, 🧠 Analisi, 📊 Conclusione.`; break;
    }

    const headerInstruction = `
📺 **Video**: ${resp.meta.title}
👤 **Canale**: ${resp.meta.channel}
___________________________________________________
`;
    const fullPrompt = `${headerInstruction}\n\n${systemPrompt}\n\n---\nTRASCRIZIONE:\n${transcriptText}`;

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?key=${apiKey}`;
    
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: [{ parts: [{ text: fullPrompt }] }] })
    });

    if (!response.ok) {
      if (response.status === 429) throw new Error("🚦 TROPPE RICHIESTE. Attendi 1 minuto o usa un modello 'Flash'.");
      const errJson = await response.json().catch(() => ({}));
      throw new Error(`Errore API (${response.status}): ${errJson.error?.message || response.statusText}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      const regex = /"text":\s*"((?:[^"\\]|\\.)*)"/g;
      let match;
      while ((match = regex.exec(chunk)) !== null) {
        let textSegment = match[1].replace(/\\n/g, "\n").replace(/\\"/g, '"').replace(/\\\\/g, "\\").replace(/\\t/g, "\t");
        fullText += textSegment;
        output.value = fullText;
        output.scrollTop = output.scrollHeight;
      }
    }

    output.dataset.metaTitle = resp.meta.title;
    saveHistory(resp.meta.videoId, fullText, transcriptText, resp.meta);
    enableChat();
    checkMermaid(fullText);

  } catch (e) {
    const currentVal = output.value;
    output.value = currentVal ? `${currentVal}\n\n❌ INTERROTTO: ${e.message}` : `❌ ERRORE:\n${e.message}`;
  } finally {
    setBusy(btn, false);
  }
}

// --- CHAT (FIXED) ---
function enableChat() { $("chatSection").style.display = "block"; $("chatInput").disabled = false; $("btnChatSend").disabled = false; }

async function runChat() {
  const input = $("chatInput");
  const question = input.value.trim();
  if (!question || !window.currentTranscript) return;

  addChatBubble(question, "user");
  input.value = ""; 
  
  const loadingId = addChatBubble("Sto pensando...", "ai");

  try {
    const apiKey = $("apiKey").value.trim();
    const model = $("aiModel").value.trim();
    const prompt = `Rispondi alla domanda basandoti SOLO sulla trascrizione.\nDOMANDA: ${question}\n---\nTRASCRIZIONE:\n${window.currentTranscript.substring(0, 30000)}`;
    
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
    const fetchResp = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }) });
    const data = await fetchResp.json();
    
    const answer = data?.candidates?.[0]?.content?.parts?.[0]?.text || "Non so rispondere basandomi sul video.";
    document.getElementById(loadingId).innerText = answer;

  } catch (e) {
    document.getElementById(loadingId).innerText = "Errore nella chat.";
  }
}

function addChatBubble(text, type) {
  const div = document.createElement("div");
  div.className = `chat-bubble chat-${type}`;
  div.innerText = text;
  div.id = "msg-" + Date.now();
  $("chatHistory").appendChild(div);
  $("chatHistory").scrollTop = $("chatHistory").scrollHeight;
  return div.id;
}

// --- TEXT TO SPEECH (TTS) ---
function toggleTTS() {
  const btn = $("btnAiTTS");
  const text = $("aiOutput").value;

  if (window.speechSynthesis.speaking) {
    window.speechSynthesis.cancel();
    btn.textContent = "🔊 Ascolta";
    return;
  }

  if (!text || text.startsWith("❌")) {
    alert("Nessun testo da leggere.");
    return;
  }

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'it-IT'; 
  
  // Applica velocità selezionata
  const rate = parseFloat($("ttsRate").value) || 1.0;
  utterance.rate = rate; 

  btn.textContent = "⏹️ Ferma"; 
  
  utterance.onend = () => { btn.textContent = "🔊 Ascolta"; };
  utterance.onerror = () => { btn.textContent = "🔊 Ascolta"; };

  window.speechSynthesis.speak(utterance);
}

// --- HELPERS ---
function checkMermaid(text) { $("btnAiViewMermaid").style.display = (text.includes("```mermaid") || text.includes("graph TD")) ? "inline-flex" : "none"; }
function openMermaidLive() {
  const text = $("aiOutput").value; const match = text.match(/```mermaid([\s\S]*?)```/);
  const code = match ? match[1].trim() : text;
  const b64 = btoa(unescape(encodeURIComponent(JSON.stringify({ code, mermaid: { theme: "default" } }))));
  chrome.tabs.create({ url: `https://mermaid.live/edit#base64:${b64}` });
}
function getSafeFilename(ext) { const title = $("aiOutput").dataset.metaTitle || "Video"; return `${title.replace(/[^a-z0-9]/gi, '_').substring(0, 50)}_Summary.${ext}`; }
function downloadBlob(content, mime, filename) { const blob = new Blob([content], { type: `${mime};charset=utf-8` }); const url = URL.createObjectURL(blob); chrome.downloads.download({ url, filename, saveAs: false }); }
function saveAiCleanTxt() { const raw = $("aiOutput").value; if(!raw) return; const clean = raw.replace(/\*\*(.*?)\*\*/g, '$1').replace(/\*(.*?)\*/g, '$1').replace(/^#+\s/gm, '').replace(/^\*\s/gm, '• ').replace(/\[(.*?)\]\(.*?\)/g, '$1'); downloadBlob(clean, "text/plain", getSafeFilename("txt")); }
function saveAiTelegramMd() { const raw = $("aiOutput").value; if(!raw) return; const tgMd = raw.replace(/\*\*(.*?)\*\*/g, '*$1*').replace(/^#+\s(.*)$/gm, '*$1*'); downloadBlob(tgMd, "text/markdown", getSafeFilename("md")); }
function saveAiHtml() { const raw = $("aiOutput").value; if(!raw) return; let htmlBody = raw.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\*\*(.*?)\*\*/g, '<b>$1</b>').replace(/\*(.*?)\*/g, '<i>$1</i>').replace(/^#+\s(.*)$/gm, '<h2>$1</h2>').replace(/^\*\s(.*)$/gm, '<li>$1</li>').replace(/\n/g, '<br>'); const fullHtml = `<!DOCTYPE html><html lang="it"><head><meta charset="UTF-8"><style>body{background:#121212;color:#e0e0e0;font-family:sans-serif;padding:20px;line-height:1.6}b{color:#fff}h2{color:#4285f4;border-bottom:1px solid #333}li{margin-bottom:5px}</style></head><body>${htmlBody}</body></html>`; downloadBlob(fullHtml, "text/html", getSafeFilename("html")); }