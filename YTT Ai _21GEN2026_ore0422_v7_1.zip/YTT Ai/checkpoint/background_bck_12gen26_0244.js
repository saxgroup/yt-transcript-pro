// background.js - VERSIONE ROBUSTA

const DEFAULT_NAME_TEMPLATE = "[{channel}] {title} ({date}) [{lang}]";

function buildFilenameFromTemplate(tpl, meta, format) {
  const safe = (v) => sanitizeFilename(v || "");
  const date = meta?.publishDate || new Date().toISOString().slice(0, 10);
  const lang = meta?.language || "";
  
  const map = {
    "{title}": safe(meta?.title),
    "{channel}": safe(meta?.channel),
    "{date}": safe(date),
    "{lang}": safe(lang === "dom" ? "" : lang),
    "{videoId}": safe(meta?.videoId),
    "{format}": safe(format),
    "{tag}": safe(meta?.tag || "")
  };

  let name = tpl;
  for (const k in map) name = name.replaceAll(k, map[k]);
  return name.replace(/\[\s*\]/g, "").replace(/\(\s*\)/g, "").replace(/\s{2,}/g, " ").trim();
}

function sanitizeFilename(name) {
  return (name || "transcript").replace(/[\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 180);
}

async function ensureContent(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  } catch (e) { /* Ignora errori su pagine non permesse */ }
}

async function downloadTextFile({ filename, text, mime }) {
  const url = `data:${mime || "text/plain"};charset=utf-8,${encodeURIComponent(text)}`;
  await chrome.downloads.download({ url, filename, saveAs: false });
}

// --- NAVIGATION HELPERS ---
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitForTabComplete(tabId, timeoutMs = 30000) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.status === 'complete') return true;
  } catch {}

  return new Promise((resolve) => {
    const t0 = Date.now();
    const onUpdated = (id, info) => {
      if (id !== tabId) return;
      if (info.status === "complete") {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve(true);
      } else if (Date.now() - t0 > timeoutMs) {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve(false); // Timeout ma procediamo
      }
    };
    chrome.tabs.onUpdated.addListener(onUpdated);
  });
}

async function navigateToVideo(tabId, videoId) {
  await chrome.tabs.update(tabId, { url: `https://www.youtube.com/watch?v=${videoId}` });
  await waitForTabComplete(tabId);
  // Attesa extra per caricamento framework YouTube
  await wait(2000); 
}

// --- MAIN LISTENER ---
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === "DOWNLOAD_ONE") {
        const { tabId, format, lang } = msg;
        await ensureContent(tabId);
        
        const resp = await chrome.tabs.sendMessage(tabId, { type: "BUILD_TRANSCRIPT_FOR_CURRENT", format, lang });
        
        if (!resp?.ok) { 
          sendResponse({ ok: false, error: resp?.error || "Errore generico" }); 
          return; 
        }

        const tpl = msg.naming?.template || DEFAULT_NAME_TEMPLATE;
        resp.meta.tag = msg.naming?.tag || "";
        const base = buildFilenameFromTemplate(tpl, resp.meta, format);
        const ext = format === "srt" ? "srt" : format === "json" ? "json" : "txt";
        
        await downloadTextFile({ 
          filename: `${base}.${ext}`, 
          text: resp.text, 
          mime: format === "json" ? "application/json" : "text/plain" 
        });
        
        sendResponse({ ok: true, filename: `${base}.${ext}` });
      }

      else if (msg.type === "DOWNLOAD_PLAYLIST") {
        const { tabId, format, lang } = msg;
        await ensureContent(tabId);
        
        const idsResp = await chrome.tabs.sendMessage(tabId, { type: "GET_PLAYLIST_VIDEO_IDS" });
        if (!idsResp?.ok) { sendResponse({ ok: false, error: idsResp?.error }); return; }
        
        const videoIds = [...new Set(idsResp.videoIds || [])].filter(Boolean);
        let done = 0, skipped = 0, failed = 0;
        const tpl = msg.naming?.template || DEFAULT_NAME_TEMPLATE;
        const tag = msg.naming?.tag || "";

        for (const vid of videoIds) {
          try {
            await navigateToVideo(tabId, vid);
            await ensureContent(tabId);
            
            const built = await chrome.tabs.sendMessage(tabId, { type: "BUILD_TRANSCRIPT_FOR_CURRENT", format, lang });
            
            if (!built?.ok) { 
              built?.skipped ? skipped++ : failed++; 
              continue; 
            }
            
            built.meta.tag = tag;
            const base = buildFilenameFromTemplate(tpl, built.meta, format);
            const ext = format === "srt" ? "srt" : format === "json" ? "json" : "txt";
            
            await downloadTextFile({ 
              filename: `Playlist/${base}.${ext}`, 
              text: built.text, 
              mime: format === "json" ? "application/json" : "text/plain" 
            });
            
            done++;
            await wait(1000); // Pausa tra i download
          } catch { failed++; }
        }
        sendResponse({ ok: true, done, skipped, failed, total: videoIds.length });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
  })();
  return true;
});