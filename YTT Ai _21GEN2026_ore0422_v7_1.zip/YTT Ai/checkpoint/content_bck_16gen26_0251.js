// path/to/content.js

// content.js - VERSIONE COMPLETA (API + DOM con Timestamp Cliccabili)

(() => {
  if (globalThis.__YT_TRANSCRIPT_PRO__?.injected) return;
  globalThis.__YT_TRANSCRIPT_PRO__ = globalThis.__YT_TRANSCRIPT_PRO__ || {};
  globalThis.__YT_TRANSCRIPT_PRO__.injected = true;

  // --- UTILS ---
  function sanitizeText(s) { return (s || "").replace(/\u00a0/g, " ").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim(); }
  function getVideoIdFromUrl(urlStr) { try { return new URL(urlStr || location.href).searchParams.get("v"); } catch { return null; } }
  function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

  // --- TIME HELPERS ---
  function msToSrtTime(ms) {
    const total = Math.max(0, Number(ms) || 0);
    const h = Math.floor(total / 3600000);
    const m = Math.floor((total % 3600000) / 60000);
    const s = Math.floor((total % 60000) / 1000);
    const msRem = Math.floor(total % 1000);
    const pad = (n, len = 2) => String(n).padStart(len, "0");
    return `${pad(h)}:${pad(m)}:${pad(s)},${pad(msRem, 3)}`;
  }
  
  // --- START MODIFICATION ---
  function msToSimpleTime(ms) {
    const totalSeconds = Math.floor(Math.max(0, Number(ms) || 0) / 1000);
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    const pad = (n) => String(n).padStart(2, "0");
    return `[${pad(h)}:${pad(m)}:${pad(s)}]`;
  }
  // --- END MODIFICATION ---

  function timestampToMs(ts) {
    if (!ts) return 0;
    const parts = ts.split(":").map(Number);
    let s = 0;
    if (parts.length === 3) s = parts[0] * 3600 + parts[1] * 60 + parts[2];
    else if (parts.length === 2) s = parts[0] * 60 + parts[1];
    else s = parts[0];
    return s * 1000;
  }

  // --- API LOGIC ---
  function getCaptionTracks() {
    const pr = window.ytInitialPlayerResponse;
    if (pr?.videoDetails?.videoId !== getVideoIdFromUrl(location.href)) return [];
    const tracks = pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
    return Array.isArray(tracks) ? tracks.map(t => ({ languageCode: t.languageCode, label: t.name?.simpleText || t.languageCode, kind: t.kind || "manual", baseUrl: t.baseUrl })) : [];
  }

  async function fetchTimedText(baseUrl) {
    if (!baseUrl) return null;
    try {
      const u = new URL(baseUrl);
      u.searchParams.set("fmt", "json3");
      const res = await fetch(u.toString());
      if (!res.ok) return null;
      return await res.json();
    } catch { return null; }
  }

  function eventsToTXT(events) { return (events || []).map(e => e.segs ? sanitizeText(e.segs.map(s => s.utf8).join("")) : "").filter(Boolean).join("\n"); }

  // --- START MODIFICATION ---
  function eventsToTimedTXT(events) {
    return (events || []).map(e => {
        if (!e?.segs) return "";
        const text = sanitizeText(e.segs.map(s => s.utf8).join(""));
        return text ? `${msToSimpleTime(e.tStartMs)} ${text}` : "";
    }).filter(Boolean).join("\n");
  }
  // --- END MODIFICATION ---

  function eventsToSRT(events) {
    let idx = 1;
    const out = [];
    for (const e of events || []) {
      if (!e?.segs) continue;
      const text = sanitizeText(e.segs.map(s => s.utf8 || "").join(""));
      if (!text) continue;
      const start = msToSrtTime(e.tStartMs);
      const end = msToSrtTime((e.tStartMs || 0) + (e.dDurationMs || 0));
      out.push(String(idx++), `${start} --> ${end}`, text, "");
    }
    return out.join("\n");
  }

  // --- DOM PARSING LOGIC ---
  function getDomSegments() {
    const nodes = document.querySelectorAll("ytd-transcript-segment-renderer");
    if (!nodes.length) return [];
    const segments = [];
    nodes.forEach(node => {
      const timeEl = node.querySelector(".segment-timestamp");
      const textEl = node.querySelector(".segment-text");
      if (timeEl && textEl) {
        const timeStr = (timeEl.innerText || "").trim();
        const text = sanitizeText(textEl.innerText || "");
        if (text) segments.push({ timeStr, text });
      }
    });
    return segments;
  }

  // --- START MODIFICATION ---
  function domToTimedTXT(segments) {
    return segments.map(s => `[${s.timeStr}] ${s.text}`).join("\n");
  }
  // --- END MODIFICATION ---

  function domToSRT(segments) {
    let idx = 1;
    const out = [];
    for (let i = 0; i < segments.length; i++) {
      const cur = segments[i];
      const next = segments[i+1];
      const startMs = timestampToMs(cur.timeStr);
      const endMs = next ? timestampToMs(next.timeStr) : (startMs + 2000);
      out.push(String(idx++), `${msToSrtTime(startMs)} --> ${msToSrtTime(endMs)}`, cur.text, "");
    }
    return out.join("\n");
  }

  // --- DOM AUTO-OPEN ---
  function isTranscriptLoaded() { return document.querySelectorAll("ytd-transcript-segment-renderer").length > 0; }
  function clickElement(el) { if (!el) return false; el.click(); return true; }

  async function tryOpenTranscriptPanel() {
    if (isTranscriptLoaded()) return true;
    const selectors = [
      'button[aria-label*="transcript" i]', 
      'button[aria-label*="trascrizione" i]',
      'ytd-menu-service-item-renderer.style-scope:has-text(/^Show transcript/i)',
      'ytd-menu-service-item-renderer.style-scope:has-text(/^Mostra trascrizione/i)'
    ];
    for (const selector of selectors) {
        const btn = document.querySelector(selector);
        if (clickElement(btn)) {
            await sleep(800);
            if(isTranscriptLoaded()) return true;
        }
    }
    // Fallback menu
    const moreBtn = document.querySelector('#menu-button button, button[aria-label="More actions"], button[aria-label="Altre azioni"]');
    if(clickElement(moreBtn)){
      await sleep(400);
       const menuBtn = document.querySelector('ytd-menu-service-item-renderer.style-scope:has-text(/^Show transcript/i), ytd-menu-service-item-renderer.style-scope:has-text(/^Mostra trascrizione/i)');
       if(clickElement(menuBtn)){
         await sleep(800);
         if(isTranscriptLoaded()) return true;
       }
    }
    return false;
  }

  // --- MAIN BUILDER ---
  async function buildTranscript({ videoId, format, lang }) {
    if (!videoId) return { ok: false, error: "Video ID mancante" };
    const meta = { videoId, title: document.title.replace("- YouTube", "").trim(), channel: document.querySelector("#owner #channel-name a")?.textContent?.trim() || "" };

    const tracks = getCaptionTracks();
    if (tracks.length > 0) {
      let bestTrack = lang === "auto" ? (tracks.find(t => t.languageCode === (navigator.language||"en").split('-')[0] && t.kind !== "asr") || tracks.find(t=> t.kind !== "asr") || tracks[0]) : tracks.find(t => t.languageCode === lang);
      if (bestTrack) {
        const data = await fetchTimedText(bestTrack.baseUrl);
        if (data?.events) {
          let text = "";
          if (format === "srt") text = eventsToSRT(data.events);
          else if (format === "json") text = JSON.stringify({ meta: { ...meta, language: bestTrack.languageCode }, transcript: data }, null, 2);
          // --- START MODIFICATION ---
          else if (format === "timed-txt") text = eventsToTimedTXT(data.events);
          // --- END MODIFICATION ---
          else text = eventsToTXT(data.events);
          return { ok: true, text, meta: { ...meta, language: bestTrack.languageCode } };
        }
      }
    }

    const opened = await tryOpenTranscriptPanel();
    if (opened || isTranscriptLoaded()) {
      const segments = getDomSegments();
      if (segments.length > 0) {
        let text = "";
        if (format === "srt") text = domToSRT(segments);
        else if (format === "json") text = JSON.stringify({ meta: { ...meta, language: "dom", source: "panel" }, transcript: segments }, null, 2);
        // --- START MODIFICATION ---
        else if (format === "timed-txt") text = domToTimedTXT(segments);
        // --- END MODIFICATION ---
        else text = segments.map(s => s.text).join("\n");
        return { ok: true, text, meta: { ...meta, language: "dom" } };
      }
    }
    return { ok: false, error: "Trascrizione non disponibile." };
  }

  // --- MESSAGING ---
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
      try {
        if (msg.type === "GET_LANGS") {
          sendResponse({ ok: true, langs: getCaptionTracks() });
        } 
        else if (msg.type === "BUILD_TRANSCRIPT_FOR_CURRENT") {
          const vid = getVideoIdFromUrl(location.href);
          const res = await buildTranscript({ videoId: vid, format: msg.format, lang: msg.lang });
          sendResponse(res);
        }
        else if (msg.type === "GET_PLAYLIST_VIDEO_IDS") {
            const ids = new Set();
            document.querySelectorAll('ytd-playlist-panel-video-renderer a#wc-endpoint').forEach(a => {
                const v = new URL(a.href, location.origin).searchParams.get("v");
                if (v) ids.add(v);
            });
            sendResponse({ ok: true, videoIds: Array.from(ids) });
        }
        // --- START MODIFICATION ---
        else if (msg.type === "SEEK_VIDEO_TO") {
            const player = document.querySelector('video.html5-main-video');
            if (player) {
              player.currentTime = msg.seconds;
              player.play();
              sendResponse({ok: true});
            } else {
              sendResponse({ok: false, error: "Player non trovato."});
            }
        }
        // --- END MODIFICATION ---
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true;
  });

})();