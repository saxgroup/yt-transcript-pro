// FILE: popup.js

const $ = (id) => document.getElementById(id);

// --- CONSTANTS ---
const SYNC_KEYS = { THEME: "themePref", TPL: "nameTemplate", TAG: "nameTag", PRESET: "namePreset", AI_KEY: "geminiApiKey", AI_MODEL: "geminiModel", TTS_RATE: "ttsRate" };
const LOCAL_KEYS = { HISTORY: "videoHistory", DETACH_STATE: "detachState" };
const PRESETS = { archive: "[{tag}] [{channel}] {title} ({date}) [{lang}]", minimal: "{title} ({date})", tech: "[{tag}] [{channel}] {title} ({date}) [{lang}] [{videoId}]" };

// Variabili Globali
window.currentTranscript = null;
window.currentMeta = null;

// --- STORAGE HELPERS ---
async function getSettings(keys) { const s = await chrome.storage.sync.get(keys); const l = await chrome.storage.local.get(keys); return { ...l, ...s }; }
async function saveSetting(key, value) { await chrome.storage.sync.set({ [key]: value }); }

// --- INIT ---
document.addEventListener("DOMContentLoaded", async () => {
  await initTheme();
  initTabs();
  initNaming();
  initDownloadLogic();
  initAiLogic();
  
  $("btnDetach").addEventListener("click", detachWindow);
  
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has("tabId")) {
    $("btnDetach").style.display = "none";
    document.body.style.width = "100%";
    document.body.style.height = "100vh";
    document.querySelector(".wrap").style.width = "auto";
    await restoreStateIfDetached();
  } else {
    setTimeout(checkHistoryForCurrentVideo, 500);
  }
});

// --- WINDOW DETACH & STATE ---
async function detachWindow() {
  const tabId = await getActiveTabId();
  if (!tabId) return;
  const state = {
    output: $("aiOutput").innerHTML, // Usa innerHTML
    metaTitle: $("aiOutput").dataset.metaTitle,
    model: $("aiModel").value,
    promptType: $("aiPromptType").value,
    customPrompt: $("customPromptText").value,
    transcript: window.currentTranscript,
    meta: window.currentMeta,
    chatHtml: $("chatHistory").innerHTML,
    isChatVisible: $("chatSection").style.display === "block",
    ttsRate: $("ttsRate").value
  };
  await chrome.storage.local.set({ [LOCAL_KEYS.DETACH_STATE]: state });
  chrome.windows.create({ url: `popup.html?tabId=${tabId}`, type: "popup", width: 450, height: 700 });
  window.close();
}
async function restoreStateIfDetached() {
  const { [LOCAL_KEYS.DETACH_STATE]: state } = await chrome.storage.local.get(LOCAL_KEYS.DETACH_STATE);
  if (state) {
    $("aiOutput").innerHTML = state.output || "";
    if(state.metaTitle) $("aiOutput").dataset.metaTitle = state.metaTitle;
    $("aiModel").value = state.model;
    $("aiPromptType").value = state.promptType;
    $("customPromptText").value = state.customPrompt || "";
    if(state.ttsRate) $("ttsRate").value = state.ttsRate;
    if (state.promptType === "custom") $("customPromptWrap").style.display = "block";
    window.currentTranscript = state.transcript;
    window.currentMeta = state.meta;
    if (state.chatHtml) $("chatHistory").innerHTML = state.chatHtml;
    if (state.isChatVisible) enableChat();
    checkMermaid(state.output || "");
    document.querySelector('[data-target="tab-ai"]').click();
    await chrome.storage.local.remove(LOCAL_KEYS.DETACH_STATE);
  }
}

// --- TAB ID LOGIC ---
async function getActiveTabId() {
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has("tabId")) return parseInt(urlParams.get("tabId"), 10);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id;
}

// --- THEME ---
async function initTheme() {
  const { [SYNC_KEYS.THEME]: pref = "auto" } = await getSettings(SYNC_KEYS.THEME);
  applyTheme(pref);
  $("themeSwitch").addEventListener("click", async () => {
    const current = document.body.getAttribute("data-theme");
    let next = "dark";
    if (current === "dark") next = "light"; else if (current === "light") next = "contrast";
    await saveSetting(SYNC_KEYS.THEME, next);
    applyTheme(next);
  });
}
function applyTheme(pref) {
  let mode = pref === "auto" ? (window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light") : pref;
  document.body.setAttribute("data-theme", mode);
  const icons = { dark: "🌙", light: "☀️", contrast: "🚧" };
  $("themeSwitch").querySelector("span").textContent = icons[mode] || "🌙";
}

// --- TABS, NAMING, DOWNLOAD ---
function initTabs() {
  document.querySelectorAll(".tab-btn").forEach(btn => btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn, .tab-content").forEach(el => el.classList.remove("active"));
    btn.classList.add("active");
    $(btn.dataset.target).classList.add("active");
  }));
}
async function initNaming() {
  const stored = await getSettings([SYNC_KEYS.TPL, SYNC_KEYS.TAG, SYNC_KEYS.PRESET]);
  const preset = stored[SYNC_KEYS.PRESET] || "archive";
  $("preset").value = preset; $("tag").value = stored[SYNC_KEYS.TAG] || "";
  updateTemplateState(preset, stored[SYNC_KEYS.TPL]);
  renderPreview();
  $("preset").addEventListener("change", (e) => { updateTemplateState(e.target.value); saveNaming(); });
  ["tag", "template", "format"].forEach(id => $(id).addEventListener("input", renderPreview));
  $("tag").addEventListener("input", saveNaming);
  $("template").addEventListener("input", saveNaming);
}
function updateTemplateState(preset, savedTpl) {
  const tplEl = $("template");
  if (preset !== "custom") { tplEl.value = PRESETS[preset] || PRESETS.archive; tplEl.disabled = true; } 
  else { tplEl.disabled = false; if (savedTpl) tplEl.value = savedTpl; }
}
async function saveNaming() {
  await saveSetting(SYNC_KEYS.PRESET, $("preset").value);
  await saveSetting(SYNC_KEYS.TAG, $("tag").value);
  await saveSetting(SYNC_KEYS.TPL, $("template").value);
}
function renderPreview() {
  let s = $("template").value.replace("{title}", "Video Title").replace("{channel}", "Channel Name").replace("{date}", "2025-01-01").replace("{lang}", "IT").replace("{videoId}", "ABC123xyz").replace("{format}", $("format").value).replace("{tag}", $("tag").value);
  $("namePreview").textContent = s.replace(/\[\s*\]/g, "").replace(/\(\s*\)/g, "").replace(/\s{2,}/g, " ").trim();
}
async function initDownloadLogic() {
  loadLanguages();
  $("downloadOne").addEventListener("click", () => runDownload("one"));
  $("downloadPlaylist").addEventListener("click", () => runDownload("playlist"));
}
async function loadLanguages() {
  const tabId = await getActiveTabId();
  if (!tabId) return;
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }).catch(() => {});
  try {
    const resp = await chrome.tabs.sendMessage(tabId, { type: "GET_LANGS" });
    const sel = $("lang");
    sel.innerHTML = `<option value="auto">Auto (consigliato)</option>`;
    if (resp?.langs) {
      resp.langs.forEach(l => {
        const opt = document.createElement("option");
        opt.value = l.languageCode;
        opt.textContent = `${l.label} ${l.kind === 'asr' ? '(Auto)' : ''}`;
        sel.appendChild(opt);
      });
      $("langHint").textContent = `Rilevate ${resp.langs.length} lingue.`;
    }
  } catch(e) { $("langHint").textContent = "Nessuna lingua rilevata."; }
}
async function runDownload(mode) {
  const btn = mode === "playlist" ? $("downloadPlaylist") : $("downloadOne");
  setBusy(btn, true); setStatus("Inizio download...");
  try {
    const tabId = await getActiveTabId();
    const naming = { template: $("template").value, tag: $("tag").value };
    if (mode === "playlist") { $("progressWrap").style.display = "block"; $("progressFill").style.width = "0%"; }
    const resp = await chrome.runtime.sendMessage({ type: mode === "playlist" ? "DOWNLOAD_PLAYLIST" : "DOWNLOAD_ONE", tabId, format: $("format").value, lang: $("lang").value, naming });
    if (!resp.ok) throw new Error(resp.error);
    setStatus(mode === "playlist" ? `Finito. Scaricati: ${resp.done}, Errori: ${resp.failed}` : `Salvato: ${resp.filename}`);
  } catch (e) { setStatus(`Errore: ${e.message}`); } finally { setBusy(btn, false); if(mode === "playlist") $("progressWrap").style.display = "none"; }
}
function setBusy(btn, isBusy) { btn.disabled = isBusy; btn.classList.toggle("is-loading", isBusy); }
function setStatus(msg) { $("status").textContent = msg; }

/* =================================================================
   AI GEMINI LOGIC (TIMESTAMP-AWARE)
   ================================================================= */

async function initAiLogic() {
  const stored = await getSettings([SYNC_KEYS.AI_KEY, SYNC_KEYS.AI_MODEL, SYNC_KEYS.TTS_RATE]);
  if (stored[SYNC_KEYS.AI_KEY]) $("apiKey").value = stored[SYNC_KEYS.AI_KEY];
  if (stored[SYNC_KEYS.AI_MODEL]) $("aiModel").value = stored[SYNC_KEYS.AI_MODEL];
  if (stored[SYNC_KEYS.TTS_RATE]) $("ttsRate").value = stored[SYNC_KEYS.TTS_RATE];

  $("apiKey").addEventListener("change", (e) => saveSetting(SYNC_KEYS.AI_KEY, e.target.value.trim()));
  $("aiModel").addEventListener("change", (e) => saveSetting(SYNC_KEYS.AI_MODEL, e.target.value));
  $("ttsRate").addEventListener("change", (e) => {
    saveSetting(SYNC_KEYS.TTS_RATE, e.target.value);
    if (window.speechSynthesis.speaking) { window.speechSynthesis.cancel(); $("btnAiTTS").textContent = "🔊 Ascolta"; }
  });

  $("aiPromptType").addEventListener("change", (e) => { $("customPromptWrap").style.display = e.target.value === "custom" ? "block" : "none"; });

  $("btnAiGenerate").addEventListener("click", runAiSummary);
  $("btnAiTTS").addEventListener("click", toggleTTS);
  $("btnAiCopy").addEventListener("click", () => {
    const txt = $("aiOutput").innerText; if(!txt) return; // Usa innerText
    navigator.clipboard.writeText(txt);
    $("btnAiCopy").textContent = "Copiato!";
    setTimeout(() => $("btnAiCopy").textContent = "Copia", 1500);
  });
  $("btnAiSaveTxt").addEventListener("click", saveAiCleanTxt);
  $("btnAiSaveMd").addEventListener("click", saveAiTelegramMd);
  $("btnAiSaveHtml").addEventListener("click", saveAiHtml);
  $("btnAiViewMermaid").addEventListener("click", openMermaidLive);
  $("btnChatSend").addEventListener("click", runChat);
  $("chatInput").addEventListener("keypress", (e) => { if(e.key === "Enter") runChat(); });
  
  // --- START MODIFICATION: TIMESTAMP CLICK HANDLER ---
  $("aiOutput").addEventListener("click", handleTimestampClick);
}

// --- HISTORY ---
async function checkHistoryForCurrentVideo() {}
async function saveHistory(videoId, text, transcript, meta) {
  const stored = await chrome.storage.local.get([LOCAL_KEYS.HISTORY]);
  const history = stored[LOCAL_KEYS.HISTORY] || {};
  history[videoId] = { text, transcript, meta, date: Date.now() };
  const keys = Object.keys(history); if (keys.length > 10) delete history[keys[0]];
  await chrome.storage.local.set({ [LOCAL_KEYS.HISTORY]: history });
}
async function loadHistory(videoId) { /*...*/ }

// --- MAIN GENERATION ---
async function runAiSummary() {
  if (window.speechSynthesis.speaking) { window.speechSynthesis.cancel(); $("btnAiTTS").textContent = "🔊 Ascolta"; }
  const apiKey = $("apiKey").value.trim(); if (!apiKey) { alert("Inserisci la Google API Key."); return; }

  const btn = $("btnAiGenerate");
  const output = $("aiOutput");
  
  setBusy(btn, true);
  output.innerHTML = ""; // Pulisci HTML
  output.setAttribute("placeholder", "🤖 Gemini sta scrivendo...");
  
  try {
    const tabId = await getActiveTabId();
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }).catch(() => {});
    
    // --- START MODIFICATION: RICHIEDI TESTO CON TIMESTAMP ---
    const resp = await chrome.tabs.sendMessage(tabId, { type: "BUILD_TRANSCRIPT_FOR_CURRENT", format: "timed-txt", lang: $("lang").value });
    if (!resp?.ok) throw new Error(resp?.error || "Errore trascrizione.");
    
    window.currentTranscript = resp.text;
    window.currentMeta = resp.meta;

    const promptType = $("aiPromptType").value;
    const model = $("aiModel").value.trim(); 
    
    let systemPrompt = "";
    // --- START MODIFICATION: AGGIUNGI ISTRUZIONE TIMESTAMP ---
    const timestampInstruction = "Quando riassumi, se pertinente, includi i timestamp originali `[hh:mm:ss]` nel tuo testo per indicare a quale punto del video si riferisce una certa affermazione.";

    switch(promptType) {
      case "bullet": systemPrompt = `Crea una lista puntata dettagliata dei concetti chiave. Usa emoji. ${timestampInstruction}`; break;
      case "deep": systemPrompt = `Agisci come esperto tecnico. Analisi approfondita. ${timestampInstruction}`; break;
      case "fact": systemPrompt = `Fact Checking. Identifica errori e contraddizioni. ${timestampInstruction}`; break;
      case "tweet": systemPrompt = "Crea un thread per Twitter/X."; break;
      case "mermaid": systemPrompt = `Crea una Mappa Mentale usando la sintassi Mermaid.js. Restituisci SOLO il codice markdown.`; break;
      case "tts": systemPrompt = "Genera un riassunto che contenga solo testo, no emoji."; break;
      case "custom": systemPrompt = $("customPromptText").value; if(!systemPrompt) throw new Error("Inserisci il prompt."); break;
      default: systemPrompt = `Fornisci un Riassunto Esecutivo chiaro e conciso. ${timestampInstruction}`; break;
    }

    const fullPrompt = `📺 **Video**: ${resp.meta.title}\n👤 **Canale**: ${resp.meta.channel}\n___________________________________________________\n\n${systemPrompt}\n\n---\nTRASCRIZIONE CON TIMESTAMP:\n${resp.text}`;

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?key=${apiKey}`;
    const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ contents: [{ parts: [{ text: fullPrompt }] }] }) });

    if (!response.ok) {
      if (response.status === 429) throw new Error("🚦 TROPPE RICHIESTE. Attendi 1 minuto.");
      throw new Error(`Errore API (${response.status})`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      const regex = /"text":\s*"((?:[^"\\]|\\.)*)"/g;
      let match;
      while ((match = regex.exec(chunk)) !== null) {
        let textSegment = match[1].replace(/\\n/g, "\n").replace(/\\"/g, '"').replace(/\\\\/g, "\\");
        fullText += textSegment;
        // Renderizza in tempo reale con timestamp cliccabili
        renderClickableTimestamps(fullText);
        output.scrollTop = output.scrollHeight;
      }
    }

    output.dataset.metaTitle = resp.meta.title;
    saveHistory(resp.meta.videoId, fullText, resp.text, resp.meta);
    enableChat();
    checkMermaid(fullText);

  } catch (e) {
    const currentVal = output.innerText;
    output.innerHTML = currentVal ? `${currentVal}<br><br>❌ INTERROTTO: ${e.message}` : `❌ ERRORE:<br>${e.message}`;
  } finally {
    setBusy(btn, false);
  }
}

// --- CHAT ---
function enableChat() { $("chatSection").style.display = "block"; $("chatInput").disabled = false; $("btnChatSend").disabled = false; }
async function runChat() { /* ... (invariata) ... */ }
function addChatBubble(text, type) { /* ... (invariata) ... */ }

// --- TTS ---
function toggleTTS() {
  const btn = $("btnAiTTS");
  const text = $("aiOutput").innerText; // Usa innerText per leggere testo pulito
  if (window.speechSynthesis.speaking) { window.speechSynthesis.cancel(); btn.textContent = "🔊 Ascolta"; return; }
  if (!text || text.startsWith("❌")) { alert("Nessun testo da leggere."); return; }
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'it-IT';
  utterance.rate = parseFloat($("ttsRate").value) || 1.0;
  btn.textContent = "⏹️ Ferma";
  utterance.onend = () => { btn.textContent = "🔊 Ascolta"; };
  utterance.onerror = () => { btn.textContent = "🔊 Ascolta"; };
  window.speechSynthesis.speak(utterance);
}

// --- HELPERS (CON TIMESTAMP) ---
function timeStrToSeconds(timeStr) {
  const parts = (timeStr || "0:0:0").replace(/[\[\]]/g, '').split(':').map(Number);
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return parts[0] || 0;
}
function renderClickableTimestamps(text) {
  const output = $("aiOutput");
  const escapedText = text.replace(/</g, "&lt;").replace(/>/g, "&gt;"); // Basic escaping
  const timestampRegex = /\[(\d{1,2}:\d{2}(?::\d{2})?)\]/g;
  output.innerHTML = escapedText.replace(timestampRegex, (match, time) => 
    `<a href="#" class="timestamp-link" data-time="${time}">${match}</a>`
  );
}
async function handleTimestampClick(event) {
  if (event.target.classList.contains("timestamp-link")) {
    event.preventDefault();
    const timeStr = event.target.dataset.time;
    const seconds = timeStrToSeconds(timeStr);
    const tabId = await getActiveTabId();
    if(tabId) {
      chrome.tabs.sendMessage(tabId, { type: "SEEK_VIDEO_TO", seconds });
    }
  }
}
function checkMermaid(text) { $("btnAiViewMermaid").style.display = (text.includes("```mermaid") || text.includes("graph TD")) ? "inline-flex" : "none"; }
function openMermaidLive() { /* ... (invariata) ... */ }
function getSafeFilename(ext) { /* ... (invariata) ... */ }
function downloadBlob(content, mime, filename) { /* ... (invariata) ... */ }
function saveAiCleanTxt() { const raw = $("aiOutput").innerText; /* ... (usa innerText) ... */ }
function saveAiTelegramMd() { const raw = $("aiOutput").innerText; /* ... (usa innerText) ... */ }
function saveAiHtml() { const raw = $("aiOutput").innerText; /* ... (usa innerText) ... */ }