// FILE: popup.js (v7.1 - Final Fix Obsidian & All Features)

const $ = (id) => document.getElementById(id);

// --- CONSTANTS ---
const SYNC_KEYS = { 
  THEME: "themePref", TPL: "nameTemplate", TAG: "nameTag", PRESET: "namePreset", 
  AI_KEY: "geminiApiKey", OPENAI_KEY: "openaiKey", ANTHROPIC_KEY: "anthropicKey",
  AI_PROVIDER: "aiProvider", AI_MODEL: "aiModel", 
  TTS_RATE: "ttsRate", TTS_VOICE: "ttsVoice",
  NOTION_TOKEN: "notionToken", NOTION_DB_ID: "notionDbId", OUTPUT_LANG: "outputLang",
  FONT_SIZE: "fontSize"
};
const LOCAL_KEYS = { HISTORY: "videoHistory", DETACH_STATE: "detachState" };

const PRESETS = { 
  archive: "[{tag}] [{channel}] {title} ({date}) [{lang}]", 
  minimal: "{title} ({date})", 
  tech: "[{tag}] [{channel}] {title} ({date}) [{lang}] [{videoId}]" 
};

// Configurazione Modelli
const MODELS = {
  gemini: [
    { id: "gemini-2.5-flash", name: "Gemini 2.5 Flash (Veloce)" },
    { id: "gemini-2.5-pro", name: "Gemini 2.5 Pro (Smart)" },
    { id: "gemini-2.5-flash-lite", name: "Gemini 2.5 Flash-Lite" }
  ],
  openai: [
    { id: "gpt-4o", name: "GPT-4o (Best)" },
    { id: "gpt-4o-mini", name: "GPT-4o Mini (Fast)" },
    { id: "gpt-3.5-turbo", name: "GPT-3.5 Turbo" }
  ],
  anthropic: [
    { id: "claude-3-5-sonnet-20240620", name: "Claude 3.5 Sonnet" },
    { id: "claude-3-haiku-20240307", name: "Claude 3 Haiku" }
  ]
};

// Variabili Globali
window.currentTranscript = null;
window.currentMeta = null;
let currentFontSize = 12;

// --- STORAGE HELPERS ---
async function getSettings(keys) { const s = await chrome.storage.sync.get(keys); const l = await chrome.storage.local.get(keys); return { ...l, ...s }; }
async function saveSetting(key, value) { await chrome.storage.sync.set({ [key]: value }); }

// --- INIT ---
document.addEventListener("DOMContentLoaded", async () => {
  await initTheme();
  initTabs();
  initNaming();
  initDownloadLogic();
  initAiLogic();
  populateVoices(); 
  
  const btnDetach = $("btnDetach");
  if (btnDetach) btnDetach.addEventListener("click", detachWindow);
  
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has("tabId")) {
    if (btnDetach) {
      btnDetach.textContent = "📥"; // Icona Riattacca
      btnDetach.title = "Chiudi finestra";
      btnDetach.onclick = () => window.close();
      btnDetach.style.display = "block";
    }
    document.body.style.width = "100%";
    document.body.style.height = "100vh";
    const wrap = document.querySelector(".wrap");
    if (wrap) wrap.style.width = "auto";
    await restoreStateIfDetached();
  } else {
    setTimeout(checkHistoryForCurrentVideo, 500);
  }
});

// ... (Funzioni detachWindow, restoreStateIfDetached, getActiveTabId, initTheme, applyTheme, initTabs, initNaming, updateTemplateState, saveNaming, renderPreview, initDownloadLogic, loadLanguages, runDownload, setBusy, setStatus INVARIATE) ...
// COPIA LE FUNZIONI STANDARD DALLA VERSIONE PRECEDENTE (v6.9) PER BREVITÀ, SONO IDENTICHE.
// QUI SOTTO METTO SOLO LE PARTI MODIFICATE/AGGIUNTE.

// --- WINDOW DETACH LOGIC ---
async function detachWindow() {
  const tabId = await getActiveTabId();
  if (!tabId) return;

  const aiOutput = $("aiOutput");
  const state = {
    output: aiOutput ? aiOutput.innerHTML : "",
    metaTitle: aiOutput ? aiOutput.dataset.metaTitle : "",
    provider: $("aiProvider")?.value,
    model: $("aiModel")?.value,
    promptType: $("aiPromptType")?.value,
    customPrompt: $("customPromptText")?.value,
    transcript: window.currentTranscript,
    meta: window.currentMeta,
    chatHtml: $("chatHistory")?.innerHTML,
    isChatVisible: $("chatSection")?.style.display === "block",
    ttsRate: $("ttsRate")?.value,
    ttsVoice: $("ttsVoice")?.value,
    outputLang: $("outputLang")?.value,
    fontSize: currentFontSize,
    notionNotes: $("notionNotes")?.value,
    notionPotential: $("notionPotential")?.checked,
    notionImportance: $("notionImportance")?.value
  };

  await chrome.storage.local.set({ [LOCAL_KEYS.DETACH_STATE]: state });

  chrome.windows.create({
    url: `popup.html?tabId=${tabId}`,
    type: "popup",
    width: 450,
    height: 700
  });
  
  window.close();
}

async function restoreStateIfDetached() {
  const stored = await chrome.storage.local.get([LOCAL_KEYS.DETACH_STATE]);
  const state = stored[LOCAL_KEYS.DETACH_STATE];
  
  if (state) {
    const aiOutput = $("aiOutput");
    if (aiOutput) {
      aiOutput.innerHTML = state.output || "";
      if(state.metaTitle) aiOutput.dataset.metaTitle = state.metaTitle;
    }
    
    if(state.provider && $("aiProvider")) {
      $("aiProvider").value = state.provider;
      updateModelList(state.provider, state.model);
    }
    if($("aiPromptType")) $("aiPromptType").value = state.promptType;
    if($("customPromptText")) $("customPromptText").value = state.customPrompt || "";
    
    if($("ttsRate") && state.ttsRate) $("ttsRate").value = state.ttsRate;
    if($("ttsVoice") && state.ttsVoice) $("ttsVoice").value = state.ttsVoice;
    if($("outputLang") && state.outputLang) $("outputLang").value = state.outputLang;
    if(state.fontSize) applyFontSize(state.fontSize);
    
    if($("notionNotes")) $("notionNotes").value = state.notionNotes || "";
    if($("notionPotential") && state.notionPotential !== undefined) $("notionPotential").checked = state.notionPotential;
    if($("notionImportance") && state.notionImportance) $("notionImportance").value = state.notionImportance;
    
    if (state.promptType === "custom" && $("customPromptWrap")) $("customPromptWrap").style.display = "block";
    
    window.currentTranscript = state.transcript;
    window.currentMeta = state.meta;
    
    if (state.chatHtml && $("chatHistory")) {
      $("chatHistory").innerHTML = state.chatHtml;
      document.querySelectorAll('.chat-action-btn').forEach(btn => {
         // Re-attach listeners logic if needed
      });
    }
    if (state.isChatVisible && $("chatSection")) {
      $("chatSection").style.display = "block";
      if($("chatInput")) $("chatInput").disabled = false;
      if($("btnChatSend")) $("btnChatSend").disabled = false;
    }
    
    if(aiOutput) checkMermaid(aiOutput.innerText);
    const tabAiBtn = document.querySelector('[data-target="tab-ai"]');
    if(tabAiBtn) tabAiBtn.click();
    
    await chrome.storage.local.remove(LOCAL_KEYS.DETACH_STATE);
  }
}

// --- TAB ID LOGIC ---
async function getActiveTabId() {
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has("tabId")) return parseInt(urlParams.get("tabId"), 10);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id;
}

// --- THEME (FIXED) ---
async function initTheme() {
  const stored = await getSettings([SYNC_KEYS.THEME]);
  const pref = stored[SYNC_KEYS.THEME] || "dark";
  applyTheme(pref);
  
  const btn = $("themeSwitch");
  if (btn) {
    btn.addEventListener("click", async () => {
      const current = document.body.getAttribute("data-theme") || "dark";
      let next = "light";
      if (current === "dark") next = "light";
      else if (current === "light") next = "contrast";
      else if (current === "contrast") next = "auto";
      else next = "dark";
      
      await saveSetting(SYNC_KEYS.THEME, next);
      applyTheme(next);
    });
  }
}

function applyTheme(mode) {
  if (!mode || !["dark", "light", "contrast"].includes(mode)) {
    mode = (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) ? "dark" : "light";
  }
  document.body.setAttribute("data-theme", mode);
  
  const btn = $("themeSwitch");
  if (btn) {
    const icons = { dark: "🌙", light: "☀️", contrast: "🚧", auto: "💻" };
    btn.textContent = icons[mode] || "🌙";
  }
}

// --- TABS, NAMING, DOWNLOAD ---
function initTabs() {
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
      btn.classList.add("active");
      const target = $(btn.dataset.target);
      if(target) target.classList.add("active");
    });
  });
}
async function initNaming() {
  const stored = await getSettings([SYNC_KEYS.TPL, SYNC_KEYS.TAG, SYNC_KEYS.PRESET]);
  const preset = stored[SYNC_KEYS.PRESET] || "archive";
  if($("preset")) $("preset").value = preset;
  if($("tag")) $("tag").value = stored[SYNC_KEYS.TAG] || "";
  updateTemplateState(preset, stored[SYNC_KEYS.TPL]);
  renderPreview();
  
  if($("preset")) $("preset").addEventListener("change", (e) => { updateTemplateState(e.target.value); saveNaming(); });
  if($("tag")) $("tag").addEventListener("input", () => { saveNaming(); renderPreview(); });
  if($("template")) $("template").addEventListener("input", () => { saveNaming(); renderPreview(); });
  if($("format")) $("format").addEventListener("change", renderPreview);
}
function updateTemplateState(preset, savedTpl) {
  const tplEl = $("template");
  if (!tplEl) return;
  if (preset !== "custom") { tplEl.value = PRESETS[preset] || PRESETS.archive; tplEl.disabled = true; } 
  else { tplEl.disabled = false; if (savedTpl) tplEl.value = savedTpl; }
  renderPreview();
}
async function saveNaming() {
  await saveSetting(SYNC_KEYS.PRESET, $("preset")?.value);
  await saveSetting(SYNC_KEYS.TAG, $("tag")?.value);
  await saveSetting(SYNC_KEYS.TPL, $("template")?.value);
  renderPreview();
}
function renderPreview() {
  const tplEl = $("template");
  const namePreview = $("namePreview");
  if (!tplEl || !namePreview) return;
  
  const tpl = tplEl.value || "[{channel}] {title}";
  let s = tpl.replace("{title}", "Video Title").replace("{channel}", "Channel Name").replace("{date}", "2025-01-01").replace("{lang}", "IT").replace("{videoId}", "ABC123xyz").replace("{format}", $("format")?.value || "txt").replace("{tag}", $("tag")?.value || "");
  namePreview.textContent = s.replace(/\[\s*\]/g, "").replace(/\(\s*\)/g, "").replace(/\s{2,}/g, " ").trim();
}
async function initDownloadLogic() {
  loadLanguages();
  if($("downloadOne")) $("downloadOne").addEventListener("click", () => runDownload("one"));
  if($("downloadPlaylist")) $("downloadPlaylist").addEventListener("click", () => runDownload("playlist"));
  if($("btnDlSaveNotion")) $("btnDlSaveNotion").addEventListener("click", runSaveTranscriptToNotion);
  // FIX: Aggiunto listener per Obsidian nella Tab Download
  if($("btnDlSaveObsidian")) $("btnDlSaveObsidian").addEventListener("click", runSaveTranscriptToObsidian);
}
async function loadLanguages() {
  const tabId = await getActiveTabId();
  if (!tabId) return;
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }).catch(() => {});
  try {
    const resp = await chrome.tabs.sendMessage(tabId, { type: "GET_LANGS" });
    const sel = $("lang");
    if (sel) {
      sel.innerHTML = `<option value="auto">Auto (consigliato)</option>`;
      if (resp && resp.langs) {
        resp.langs.forEach(l => {
          const opt = document.createElement("option");
          opt.value = l.languageCode;
          opt.textContent = `${l.label} ${l.kind === 'asr' ? '(Auto)' : ''}`;
          sel.appendChild(opt);
        });
        if($("langHint")) $("langHint").textContent = `Rilevate ${resp.langs.length} lingue.`;
      }
    }
  } catch(e) { if($("langHint")) $("langHint").textContent = "Nessuna lingua rilevata."; }
}
async function runDownload(mode) {
  const btn = mode === "playlist" ? $("downloadPlaylist") : $("downloadOne");
  setBusy(btn, true);
  setStatus("Inizio download...");
  try {
    const tabId = await getActiveTabId();
    const naming = { template: $("template")?.value, tag: $("tag")?.value };
    if (mode === "playlist") { $("progressWrap").style.display = "block"; $("progressFill").style.width = "0%"; }
    const resp = await chrome.runtime.sendMessage({ type: mode === "playlist" ? "DOWNLOAD_PLAYLIST" : "DOWNLOAD_ONE", tabId, format: $("format")?.value, lang: $("lang")?.value, naming });
    if (!resp.ok) throw new Error(resp.error);
    setStatus(mode === "playlist" ? `Finito. Scaricati: ${resp.done}, Errori: ${resp.failed}` : `Salvato: ${resp.filename}`);
  } catch (e) { setStatus(`Errore: ${e.message}`); } finally { setBusy(btn, false); if(mode === "playlist") $("progressWrap").style.display = "none"; }
}
function setBusy(btn, isBusy) { if(btn) { btn.disabled = isBusy; btn.classList.toggle("is-loading", isBusy); } }
function setStatus(msg) { if($("status")) $("status").textContent = msg; }


/* =================================================================
   AI LOGIC (UPDATED)
   ================================================================= */

async function initAiLogic() {
  const stored = await getSettings(Object.values(SYNC_KEYS));
  
  // ... (Caricamento chiavi e settings invariato) ...
  if (stored[SYNC_KEYS.AI_KEY] && $("apiKey")) $("apiKey").value = stored[SYNC_KEYS.AI_KEY];
  if (stored[SYNC_KEYS.OPENAI_KEY] && $("openaiKey")) $("openaiKey").value = stored[SYNC_KEYS.OPENAI_KEY];
  if (stored[SYNC_KEYS.ANTHROPIC_KEY] && $("anthropicKey")) $("anthropicKey").value = stored[SYNC_KEYS.ANTHROPIC_KEY];
  
  if (stored[SYNC_KEYS.TTS_RATE] && $("ttsRate")) $("ttsRate").value = stored[SYNC_KEYS.TTS_RATE];
  if (stored[SYNC_KEYS.TTS_VOICE] && $("ttsVoice")) $("ttsVoice").value = stored[SYNC_KEYS.TTS_VOICE];
  if (stored[SYNC_KEYS.NOTION_TOKEN] && $("notionToken")) $("notionToken").value = stored[SYNC_KEYS.NOTION_TOKEN];
  if (stored[SYNC_KEYS.NOTION_DB_ID] && $("notionDbId")) $("notionDbId").value = stored[SYNC_KEYS.NOTION_DB_ID];
  if (stored[SYNC_KEYS.OUTPUT_LANG] && $("outputLang")) $("outputLang").value = stored[SYNC_KEYS.OUTPUT_LANG];
  if (stored[SYNC_KEYS.FONT_SIZE]) applyFontSize(stored[SYNC_KEYS.FONT_SIZE]);

  const provider = stored[SYNC_KEYS.AI_PROVIDER] || "gemini";
  if($("aiProvider")) $("aiProvider").value = provider;
  updateModelList(provider, stored[SYNC_KEYS.AI_MODEL]);

  // ... (Listeners invariati) ...
  if($("apiKey")) $("apiKey").addEventListener("change", (e) => saveSetting(SYNC_KEYS.AI_KEY, e.target.value.trim()));
  if($("openaiKey")) $("openaiKey").addEventListener("change", (e) => saveSetting(SYNC_KEYS.OPENAI_KEY, e.target.value.trim()));
  if($("anthropicKey")) $("anthropicKey").addEventListener("change", (e) => saveSetting(SYNC_KEYS.ANTHROPIC_KEY, e.target.value.trim()));

  if($("aiProvider")) $("aiProvider").addEventListener("change", (e) => {
    const newProvider = e.target.value;
    saveSetting(SYNC_KEYS.AI_PROVIDER, newProvider);
    updateModelList(newProvider);
  });
  
  if($("aiModel")) $("aiModel").addEventListener("change", (e) => saveSetting(SYNC_KEYS.AI_MODEL, e.target.value));

  if($("notionToken")) $("notionToken").addEventListener("change", (e) => saveSetting(SYNC_KEYS.NOTION_TOKEN, e.target.value.trim()));
  if($("notionDbId")) $("notionDbId").addEventListener("change", (e) => saveSetting(SYNC_KEYS.NOTION_DB_ID, e.target.value.trim()));
  if($("outputLang")) $("outputLang").addEventListener("change", (e) => saveSetting(SYNC_KEYS.OUTPUT_LANG, e.target.value));
  
  if($("ttsRate")) $("ttsRate").addEventListener("change", (e) => {
    saveSetting(SYNC_KEYS.TTS_RATE, e.target.value);
    if (window.speechSynthesis.speaking) { window.speechSynthesis.cancel(); resetTTSUI(); }
  });
  if($("ttsVoice")) $("ttsVoice").addEventListener("change", (e) => {
    saveSetting(SYNC_KEYS.TTS_VOICE, e.target.value);
    if (window.speechSynthesis.speaking) { window.speechSynthesis.cancel(); resetTTSUI(); }
  });

  if($("aiPromptType")) $("aiPromptType").addEventListener("change", (e) => {
    if($("customPromptWrap")) $("customPromptWrap").style.display = e.target.value === "custom" ? "block" : "none";
  });

  if($("deepSearchInput")) $("deepSearchInput").addEventListener("input", (e) => performDeepSearch(e.target.value));

  if($("btnAiGenerate")) $("btnAiGenerate").addEventListener("click", runAiSummary);
  if($("btnScreenshot")) $("btnScreenshot").addEventListener("click", captureVideoFrame);
  if($("btnAiAnalyzeComments")) $("btnAiAnalyzeComments").addEventListener("click", analyzeComments);
  
  if($("btnAiTTS")) $("btnAiTTS").addEventListener("click", toggleTTS);
  if($("btnAiStop")) $("btnAiStop").addEventListener("click", stopTTS);

  if($("btnAiCopy")) $("btnAiCopy").addEventListener("click", () => {
    let txt = $("aiOutput").innerText; if(!txt) return; 
    txt = removeTimestamps(txt); 
    navigator.clipboard.writeText(txt);
    $("btnAiCopy").textContent = "Copiato!";
    setTimeout(() => $("btnAiCopy").textContent = "Copia", 1500);
  });
  
  if($("btnAiSaveTxt")) $("btnAiSaveTxt").addEventListener("click", saveAiCleanTxt);
  if($("btnAiSaveMd")) $("btnAiSaveMd").addEventListener("click", saveAiTelegramMd);
  if($("btnAiSaveHtml")) $("btnAiSaveHtml").addEventListener("click", saveAiHtml);
  if($("btnAiSaveMp3")) $("btnAiSaveMp3").addEventListener("click", saveAiMp3);
  if($("btnAiSavePdf")) $("btnAiSavePdf").addEventListener("click", saveAiPdf);
  
  if($("btnAiViewMermaid")) $("btnAiViewMermaid").addEventListener("click", openMermaidLive);
  if($("btnAiSaveObsidian")) $("btnAiSaveObsidian").addEventListener("click", saveToObsidian);
  if($("btnAiSaveNotion")) $("btnAiSaveNotion").addEventListener("click", runSaveAiToNotion);
  
  // NUOVO: Pulsante Condividi
  if($("btnAiShare")) $("btnAiShare").addEventListener("click", shareResult);
  
  // NUOVO: Pulsante Bug Report
  if($("btnReportBug")) $("btnReportBug").addEventListener("click", () => {
    chrome.tabs.create({ url: "mailto:saxgroup@saxgroup.it?subject=Segnalazione YT Transcript Pro" });
  });
  
  if($("btnChatSend")) $("btnChatSend").addEventListener("click", runChat);
  if($("chatInput")) $("chatInput").addEventListener("keypress", (e) => { if(e.key === "Enter") runChat(); });
  
  // Global Chat Export
  if($("btnChatSaveTxt")) $("btnChatSaveTxt").addEventListener("click", () => exportFullChat("txt"));
  if($("btnChatSaveObsidian")) $("btnChatSaveObsidian").addEventListener("click", () => exportFullChat("obsidian"));
  if($("btnChatSaveNotion")) $("btnChatSaveNotion").addEventListener("click", () => exportFullChat("notion"));

  if($("aiOutput")) $("aiOutput").addEventListener("click", handleTimestampClick);

  // ZOOM LISTENERS
  if($("btnZoomIn")) $("btnZoomIn").addEventListener("click", () => applyFontSize(currentFontSize + 2));
  if($("btnZoomOut")) $("btnZoomOut").addEventListener("click", () => applyFontSize(currentFontSize - 2));
  if($("btnZoomReset")) $("btnZoomReset").addEventListener("click", () => applyFontSize(12));
}

function updateModelList(provider, selectedId = null) {
  const select = $("aiModel");
  if (!select) return;
  select.innerHTML = "";
  if (MODELS[provider]) {
    MODELS[provider].forEach(m => {
      const opt = document.createElement("option");
      opt.value = m.id;
      opt.textContent = m.name;
      if (m.id === selectedId) opt.selected = true;
      select.appendChild(opt);
    });
  }
}

// --- ZOOM LOGIC ---
function applyFontSize(size) {
  if (size < 8) size = 8;
  if (size > 24) size = 24;
  currentFontSize = size;
  const out = $("aiOutput");
  if (out) out.style.fontSize = size + "px";
  saveSetting(SYNC_KEYS.FONT_SIZE, size);
  const resetBtn = $("btnZoomReset");
  if (resetBtn) resetBtn.textContent = size + "px";
}

// --- HISTORY ---
async function checkHistoryForCurrentVideo() { try { const tabId = await getActiveTabId(); } catch {} }
async function saveHistory(videoId, text, transcript, meta) {
  const stored = await chrome.storage.local.get([LOCAL_KEYS.HISTORY]);
  const history = stored[LOCAL_KEYS.HISTORY] || {};
  history[videoId] = { text, transcript, meta, date: Date.now() };
  const keys = Object.keys(history); if (keys.length > 10) delete history[keys[0]];
  await chrome.storage.local.set({ [LOCAL_KEYS.HISTORY]: history });
}
async function loadHistory(videoId) {
  const stored = await chrome.storage.local.get([LOCAL_KEYS.HISTORY]);
  const entry = stored[LOCAL_KEYS.HISTORY]?.[videoId];
  if (entry) {
    const out = $("aiOutput");
    if (out) {
      out.innerHTML = entry.text;
      out.dataset.metaTitle = entry.meta.title;
    }
    window.currentTranscript = entry.transcript;
    window.currentMeta = entry.meta;
    if($("historyBadge")) $("historyBadge").style.display = "inline-block";
    enableChat();
    if(out) checkMermaid(out.innerText); 
    return true;
  }
  return false;
}

// --- CHUNKING LOGIC ---
async function summarizeInChunks(transcript, apiKey, model, fullPromptBase) {
  const chunkSize = 25000; const chunks = [];
  for (let i = 0; i < transcript.length; i += chunkSize) chunks.push(transcript.substring(i, i + chunkSize));
  const chunkSummaries = await Promise.all(chunks.map(chunk => {
    const chunkPrompt = `Riassumi brevemente questo segmento:\n\n${chunk}`;
        // Nota: Qui usiamo sempre Gemini per il chunking per semplicità
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
    return fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ contents: [{ parts: [{ text: chunkPrompt }] }] }) })
      .then(res => res.json()).then(data => data.candidates?.[0]?.content?.parts?.[0]?.text || "");
  }));
  return `${fullPromptBase}\n\nTRASCRIZIONE (RIASSUNTI PARZIALI):\n${chunkSummaries.join("\n\n---\n\n")}`;
}

// --- MAIN GENERATION ---
async function runAiSummary() {
  stopTTS();
  const provider = $("aiProvider").value;
  const model = $("aiModel").value;
  
  let apiKey = "";
  if (provider === "gemini") apiKey = $("apiKey").value.trim();
  else if (provider === "openai") apiKey = $("openaiKey").value.trim();
  else if (provider === "anthropic") apiKey = $("anthropicKey").value.trim();

  if (!apiKey) { alert(`Inserisci la API Key per ${provider}.`); return; }

  const btn = $("btnAiGenerate");
  const output = $("aiOutput");
  setBusy(btn, true);
  output.innerHTML = ""; output.setAttribute("placeholder", `🤖 ${provider} sta scrivendo...`);
  
  // ANIMAZIONE PULSANTE
  btn.classList.add("btn-anim-pulse");

  try {
    const tabId = await getActiveTabId();
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }).catch(() => {});
    const resp = await chrome.tabs.sendMessage(tabId, { type: "BUILD_TRANSCRIPT_FOR_CURRENT", format: "timed-txt", lang: $("lang").value });
    if (!resp?.ok) throw new Error(resp?.error || "Errore trascrizione.");
    
    window.currentTranscript = resp.text;
    window.currentMeta = resp.meta;

    const promptType = $("aiPromptType").value;
    const outputLang = $("outputLang").value;
    
    let systemPrompt = "";
    const timestampInstruction = "Se pertinente, includi i timestamp originali `[hh:mm:ss]` nel testo.";
    const langInstruction = `Rispondi esclusivamente in lingua ${outputLang}.`;

    switch(promptType) {
      case "bullet": systemPrompt = `Crea una lista puntata dettagliata dei concetti chiave. Usa emoji. ${timestampInstruction}`; break;
      case "deep": systemPrompt = `Agisci come esperto tecnico. Analisi approfondita. ${timestampInstruction}`; break;
      case "fact": systemPrompt = `Fact Checking. Identifica errori e contraddizioni. ${timestampInstruction}`; break;
      case "tweet": systemPrompt = "Crea un thread per Twitter/X."; break;
      case "linkedin": systemPrompt = "Crea un post professionale per LinkedIn. Usa bullet points e hashtag business."; break;
      case "facebook": systemPrompt = "Crea un post ingaggiante per Facebook. Includi una domanda per il pubblico."; break;
      case "quiz": systemPrompt = "Genera 5 domande a risposta multipla basate sul video. Usa il formato spoiler Markdown (es. ||risposta||) per nascondere la soluzione."; break;
      case "mermaid": systemPrompt = `Crea una Mappa Mentale usando la sintassi Mermaid.js. Restituisci SOLO il codice markdown.`; break;
      case "tts": systemPrompt = "Genera un riassunto che contenga solo testo, no emoji."; break;
      case "custom": systemPrompt = $("customPromptText").value; if(!systemPrompt) throw new Error("Inserisci il prompt."); break;
      default: systemPrompt = `Fornisci un Riassunto Esecutivo chiaro e conciso. ${timestampInstruction}`; break;
    }

    const headerInstruction = `📺 **Video**: ${resp.meta.title}\n👤 **Canale**: ${resp.meta.channel}\n___________________________________________________`;
    let fullPrompt = "";
    const basePrompt = `${headerInstruction}\n\n${systemPrompt}\n\n${langInstruction}`;

    if (resp.text.length > 80000 && provider === "gemini") {
      output.setAttribute("placeholder", "🤖 Video lungo, sto analizzando in blocchi...");
      fullPrompt = await summarizeInChunks(resp.text, apiKey, model, basePrompt);
    } else {
      fullPrompt = `${basePrompt}\n\n---\nTRASCRIZIONE CON TIMESTAMP:\n${resp.text.substring(0, 100000)}`;
    }

    // --- API CALL ROUTER ---
    if (provider === "gemini") {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?key=${apiKey}`;
      const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ contents: [{ parts: [{ text: fullPrompt }] }] }) });
      if (!response.ok) throw new Error(`Errore API (${response.status})`);
      
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let fullText = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        const regex = /"text":\s*"((?:[^"\\]|\\.)*)"/g;
        let match;
        while ((match = regex.exec(chunk)) !== null) {
          let textSegment = match[1].replace(/\\n/g, "\n").replace(/\\"/g, '"').replace(/\\\\/g, "\\").replace(/\\t/g, "\t");
          fullText += textSegment;
          renderClickableTimestamps(fullText);
          output.scrollTop = output.scrollHeight;
        }
      }
      saveHistory(resp.meta.videoId, $("aiOutput").innerHTML, resp.text, resp.meta);
    } 
    else if (provider === "openai") {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
        body: JSON.stringify({ model: model, messages: [{ role: "user", content: fullPrompt }] })
      });
      const data = await response.json();
      if (data.error) throw new Error(data.error.message);
      const text = data.choices[0].message.content;
      renderClickableTimestamps(text);
      saveHistory(resp.meta.videoId, $("aiOutput").innerHTML, resp.text, resp.meta);
    }
    else if (provider === "anthropic") {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "x-api-key": apiKey, "anthropic-version": "2023-06-01", "content-type": "application/json" },
        body: JSON.stringify({ model: model, max_tokens: 4000, messages: [{ role: "user", content: fullPrompt }] })
      });
      const data = await response.json();
      if (data.error) throw new Error(data.error.message);
      const text = data.content[0].text;
      renderClickableTimestamps(text);
      saveHistory(resp.meta.videoId, $("aiOutput").innerHTML, resp.text, resp.meta);
    }

    enableChat();
    checkMermaid($("aiOutput").innerText);

  } catch (e) {
    const currentVal = output.innerText;
    output.innerHTML = currentVal ? `${currentVal}<br><br>❌ INTERROTTO: ${e.message}` : `❌ ERRORE:<br>${e.message}`;
  } finally {
    setBusy(btn, false);
    btn.classList.remove("btn-anim-pulse");
  }
}

// --- DEEP SEARCH ---
function performDeepSearch(query) {
  const container = $("deepSearchResults");
  if (!query || query.length < 3 || !window.currentTranscript) {
    container.style.display = "none"; return;
  }
  
  const regex = new RegExp(`\\[(\\d+:\\d+)\\][^\\n]*${query}[^\\n]*`, "gi");
  const matches = window.currentTranscript.match(regex) || [];
  
  container.innerHTML = "";
  if (matches.length > 0) {
    container.style.display = "block";
    matches.slice(0, 10).forEach(match => {
      const div = document.createElement("div");
      div.className = "search-item";
      const timeMatch = match.match(/\[(\d+:\d+)\]/);
      const time = timeMatch ? timeMatch[1] : "00:00";
      div.innerHTML = `<b>${time}</b> ${match.replace(/\[.*?\]/, "").substring(0, 60)}...`;
      div.onclick = async () => {
        const tabId = await getActiveTabId();
        chrome.tabs.sendMessage(tabId, { type: "SEEK_VIDEO_TO", seconds: timeStrToSeconds(time) });
      };
      container.appendChild(div);
    });
  } else {
    container.style.display = "none";
  }
}

// --- SCREENSHOT ---
async function captureVideoFrame() {
  const tabId = await getActiveTabId();
  const resp = await chrome.tabs.sendMessage(tabId, { type: "CAPTURE_SCREENSHOT" });
  if (resp?.ok && resp.dataUrl) {
    const a = document.createElement("a");
    a.href = resp.dataUrl;
    a.download = `Screenshot_${Date.now()}.png`;
    a.click();
  } else {
    alert("Impossibile catturare screenshot. Assicurati che il video sia in riproduzione.");
  }
}

// --- COMMENTS ANALYSIS ---
async function analyzeComments() {
  const tabId = await getActiveTabId();
  const resp = await chrome.tabs.sendMessage(tabId, { type: "GET_COMMENTS" });
  if (!resp?.ok || !resp.comments) { alert("Nessun commento trovato (scorri la pagina per caricarli)."); return; }
  
  const prompt = `Analizza questi commenti di YouTube. Qual è il sentiment generale? Quali sono le critiche o i complimenti principali?\n\n${resp.comments}`;
  
  $("customPromptText").value = prompt;
  $("aiPromptType").value = "custom";
  $("customPromptWrap").style.display = "block";
  runAiSummary();
}

// --- SHARE ---
function shareResult() {
  const text = $("aiOutput").innerText;
  if (!text) return;
  if (navigator.share) {
    navigator.share({
      title: 'Riassunto Video',
      text: text
    }).catch(console.error);
  } else {
    navigator.clipboard.writeText(text);
    alert("Testo copiato negli appunti (Condivisione non supportata).");
  }
}

// --- OBSIDIAN TRANSCRIPT (TXT+SRT) - ROBUSTA ---
async function runSaveTranscriptToObsidian() {
  const btn = $("btnDlSaveObsidian");
  const originalText = btn.textContent;
  btn.textContent = "⏳ Scarico...";
  btn.disabled = true;

  try {
    const tabId = await getActiveTabId();
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }).catch(() => {});
    
    // 1. Scarica TXT
    const respTxt = await chrome.tabs.sendMessage(tabId, { 
      type: "BUILD_TRANSCRIPT_FOR_CURRENT", 
      format: "txt", 
      lang: $("lang").value 
    });
    if (!respTxt?.ok) throw new Error("Errore trascrizione TXT.");
    
    // 2. Scarica SRT
    const respSrt = await chrome.tabs.sendMessage(tabId, { 
      type: "BUILD_TRANSCRIPT_FOR_CURRENT", 
      format: "srt", 
      lang: $("lang").value 
    });
    if (!respSrt?.ok) throw new Error("Errore trascrizione SRT.");

    // 3. Genera Nome e Contenuto
    // Usa la nuova funzione generateUniqueTitle che abbiamo corretto (senza due punti)
    const fileName = generateUniqueTitle(respTxt.meta, "TRANSCRIPT");
    const content = `# ${respTxt.meta.title}\n\n## TXT\n${respTxt.text}\n\n## SRT\n${respSrt.text}`;
    
    // 4. Apri Obsidian
    const url = `obsidian://new?name=${encodeURIComponent(fileName)}&content=${encodeURIComponent(content)}`;
    chrome.tabs.create({ url });

  } catch (e) {
    alert("Errore: " + e.message);
  } finally {
    btn.textContent = originalText;
    btn.disabled = false;
  }
}
// --- CHAT (FIXED & BUTTONS) ---
function enableChat() { $("chatSection").style.display = "block"; $("chatInput").disabled = false; $("btnChatSend").disabled = false; }

async function runChat() {
  const input = $("chatInput"); const question = input.value.trim(); 
  if (!window.currentTranscript) {
    const success = await ensureVideoData();
    if (!success) { alert("Impossibile recuperare i dati del video."); return; }
  }
  if (!question) return;

  addChatBubble(question, "user");
  input.value = ""; 
  input.disabled = true; 
  
  const loadingId = addChatBubble("Sto pensando...", "ai");

  try {
    const provider = $("aiProvider").value;
    const model = $("aiModel").value;
    let apiKey = "";
    if (provider === "gemini") apiKey = $("apiKey").value;
    else if (provider === "openai") apiKey = $("openaiKey").value;
    else if (provider === "anthropic") apiKey = $("anthropicKey").value;

    const transcriptContext = window.currentTranscript.substring(0, 50000); 
    const prompt = `Rispondi alla domanda basandoti SOLO sulla trascrizione seguente.\nDOMANDA: ${question}\n---\nTRASCRIZIONE:\n${transcriptContext}`;
    
    let answer = "Non so.";

    if (provider === "gemini") {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
      const fetchResp = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }) });
      const data = await fetchResp.json();
      answer = data?.candidates?.[0]?.content?.parts?.[0]?.text || "Non so.";
    } else if (provider === "openai") {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
        body: JSON.stringify({ model: model, messages: [{ role: "user", content: prompt }] })
      });
      const data = await response.json();
      answer = data.choices[0].message.content;
    }
    
    const bubble = document.getElementById(loadingId);
    bubble.innerText = answer;
    appendChatButtons(bubble, answer);

  } catch (e) {
    document.getElementById(loadingId).innerText = "Errore chat: " + e.message;
  } finally {
    input.disabled = false;
    input.focus();
  }
}

function addChatBubble(text, type) {
  const container = document.createElement("div");
  container.className = "chat-bubble-container";
  
  const bubble = document.createElement("div");
  bubble.className = `chat-bubble chat-${type}`;
  bubble.innerText = text;
  bubble.id = "msg-" + Date.now() + "-" + Math.floor(Math.random() * 1000);
  
  container.appendChild(bubble);
  $("chatHistory").appendChild(container);
  $("chatHistory").scrollTop = $("chatHistory").scrollHeight;
  
  return bubble.id;
}

function appendChatButtons(bubbleElement, textContent) {
  if (!bubbleElement.classList.contains("chat-ai")) return;

  const actionsDiv = document.createElement("div");
  actionsDiv.className = "chat-actions";
  
  const btnTxt = document.createElement("button");
  btnTxt.className = "chat-action-btn";
  btnTxt.innerText = "📄";
  btnTxt.title = "Salva TXT";
  btnTxt.onclick = () => downloadBlob(textContent, "text/plain", "chat_response.txt");
  
  const btnObs = document.createElement("button");
  btnObs.className = "chat-action-btn";
  btnObs.innerText = "💎";
  btnObs.title = "Salva Obsidian";
  btnObs.onclick = () => {
    const fileName = generateUniqueTitle(window.currentMeta, "CHAT");
    const url = `obsidian://new?name=${encodeURIComponent(fileName)}&content=${encodeURIComponent(textContent)}`;
    chrome.tabs.create({ url });
  };
  
  const btnNot = document.createElement("button");
  btnNot.className = "chat-action-btn";
  btnNot.innerText = "🇳";
  btnNot.title = "Append to Notion";
  btnNot.onclick = () => saveChatToNotion(textContent);

  // NUOVO: Pulsante TTS per singolo messaggio
  const btnTts = document.createElement("button");
  btnTts.className = "chat-action-btn";
  btnTts.innerText = "🔊";
  btnTts.title = "Leggi";
  btnTts.onclick = () => {
    const utterance = new SpeechSynthesisUtterance(textContent);
    utterance.lang = 'it-IT';
    window.speechSynthesis.speak(utterance);
  };

  actionsDiv.appendChild(btnTxt);
  actionsDiv.appendChild(btnObs);
  actionsDiv.appendChild(btnNot);
  actionsDiv.appendChild(btnTts);
  
  bubbleElement.parentNode.appendChild(actionsDiv);
}

// --- CHAT EXPORT HELPERS ---
function exportFullChat(format) {
  const history = $("chatHistory");
  let fullText = "";
  
  history.querySelectorAll(".chat-bubble").forEach(bubble => {
    const isUser = bubble.classList.contains("chat-user");
    const speaker = isUser ? "TU" : "AI";
    fullText += `**${speaker}:** ${bubble.innerText}\n\n`;
  });

  if (!fullText) { alert("Chat vuota."); return; }

  if (format === "txt") downloadBlob(fullText, "text/plain", "full_chat.txt");
  else if (format === "obsidian") {
    const fileName = generateUniqueTitle(window.currentMeta, "FULL-CHAT");
    const url = `obsidian://new?name=${encodeURIComponent(fileName)}&content=${encodeURIComponent(fullText)}`;
    chrome.tabs.create({ url });
  }
  else if (format === "notion") {
    saveChatToNotion(fullText, true);
  }
}

async function saveChatToNotion(text, isFullChat = false) {
  const token = $("notionToken").value; const dbId = $("notionDbId").value;
  if (!token || !dbId) { alert("Configura Notion."); return; }
  const meta = window.currentMeta;
  if (!meta?.videoId) { alert("Dati video mancanti."); return; }

  try {
    const pageId = await findNotionPageByVideoId(dbId, token, meta.videoId);
    
    if (pageId) {
      const heading = isFullChat ? "💬 Chat Completa" : "💬 Risposta Chat";
      const blocks = [
        { object: 'block', type: 'heading_3', heading_3: { rich_text: [{ text: { content: heading } }] } },
        { object: 'block', type: 'paragraph', paragraph: { rich_text: [{ text: { content: text.substring(0, 2000) } }] } }
      ];
      
      await notionFetch(`https://api.notion.com/v1/blocks/${pageId}/children`, token, {
        method: "PATCH",
        body: JSON.stringify({ children: blocks })
      });
      alert("✅ Aggiunto alla pagina Notion!");
    } else {
      alert("Pagina video non trovata su Notion. Salva prima il riassunto o la trascrizione.");
    }
  } catch (e) { alert("Errore Notion: " + e.message); }
}

// --- TTS ---
async function populateVoices() {
  const voiceSelect = $("ttsVoice"); const stored = await getSettings([SYNC_KEYS.TTS_VOICE]);
  function loadVoices() {
    const voices = speechSynthesis.getVoices(); voiceSelect.innerHTML = "<option value=''>Default</option>";
    voices.forEach(voice => { const option = document.createElement('option'); option.textContent = `${voice.name} (${voice.lang})`; option.value = voice.name; if (voice.name === stored[SYNC_KEYS.TTS_VOICE]) option.selected = true; voiceSelect.appendChild(option); });
  }
  loadVoices(); if (speechSynthesis.onvoiceschanged !== undefined) speechSynthesis.onvoiceschanged = loadVoices;
}
function toggleTTS() {
  const btn = $("btnAiTTS"); const stopBtn = $("btnAiStop"); const synth = window.speechSynthesis;
  if (synth.speaking) { if (synth.paused) { synth.resume(); btn.textContent = "⏸️ Pausa"; } else { synth.pause(); btn.textContent = "▶️ Riprendi"; } return; }
  const selection = window.getSelection().toString().trim();
  let textToRead = selection ? selection : $("aiOutput").innerText;
  if (!textToRead || textToRead.startsWith("❌")) { alert("Nessun testo."); return; }
  textToRead = removeTimestamps(removeEmojis(textToRead));
  const utterance = new SpeechSynthesisUtterance(textToRead);
  utterance.lang = 'it-IT'; utterance.rate = parseFloat($("ttsRate").value) || 1.0;
  const selectedVoiceName = $("ttsVoice").value;
  if (selectedVoiceName) { const v = synth.getVoices().find(v => v.name === selectedVoiceName); if(v) utterance.voice = v; }
  utterance.onstart = () => { btn.textContent = "⏸️ Pausa"; stopBtn.style.display = "inline-block"; };
  utterance.onend = () => { resetTTSUI(); }; utterance.onerror = () => { resetTTSUI(); };
  synth.speak(utterance);
}
function stopTTS() { const synth = window.speechSynthesis; if (synth.speaking || synth.paused) synth.cancel(); resetTTSUI(); }
function resetTTSUI() { $("btnAiTTS").textContent = "🔊 Ascolta"; $("btnAiStop").style.display = "none"; }

// --- MP3 ---
async function saveAiMp3() {
  const btn = $("btnAiSaveMp3"); let text = $("aiOutput").innerText; if (!text || text.startsWith("❌")) { alert("Nessun testo."); return; }
  text = removeTimestamps(removeEmojis(text)).replace(/[*#_`]/g, '');
  const originalText = btn.textContent; btn.textContent = "⏳ Generazione..."; btn.disabled = true;
  try {
    const chunks = splitTextForTTS(text, 180); const audioBlobs = [];
    const langMap = { "Italiano": "it", "English": "en", "Spanish": "es", "French": "fr", "German": "de" };
    const targetLang = langMap[$("outputLang").value] || "it";
    for (const chunk of chunks) {
      if (!chunk.trim()) continue;
      const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(chunk)}&tl=${targetLang}&client=tw-ob`;
      const resp = await fetch(url); if (!resp.ok) throw new Error("Errore download audio");
      audioBlobs.push(await resp.blob());
    }
    const finalBlob = new Blob(audioBlobs, { type: "audio/mpeg" });
    chrome.downloads.download({ url: URL.createObjectURL(finalBlob), filename: getSafeFilename("mp3"), saveAs: false });
  } catch (e) { alert("Errore MP3: " + e.message); } finally { btn.textContent = originalText; btn.disabled = false; }
}
function splitTextForTTS(text, maxLength) {
  const chunks = []; const sentences = text.match(/[^.!?\n]+[.!?\n]*/g) || [text]; let currentChunk = "";
  for (const sentence of sentences) {
    if ((currentChunk + sentence).length <= maxLength) currentChunk += sentence;
    else { if (currentChunk) chunks.push(currentChunk); currentChunk = sentence.length > maxLength ? sentence.substring(0, maxLength) : sentence; }
  }
  if (currentChunk) chunks.push(currentChunk); return chunks;
}

// --- PDF ---
function saveAiPdf() {
  if (typeof window.jspdf === 'undefined') { alert("ERRORE: Libreria 'jspdf.min.js' non trovata."); return; }
  let text = $("aiOutput").innerText; if (!text || text.startsWith("❌")) return;
  text = removeTimestamps(removeEmojis(text));
  try {
    const { jsPDF } = window.jspdf; const doc = new jsPDF();
    const title = $("aiOutput").dataset.metaTitle || "Riassunto";
    const cleanTitle = title.replace(/[^\x20-\x7E]/g, ''); 
    doc.setFontSize(16); doc.text(doc.splitTextToSize(cleanTitle, 180), 10, 15);
    doc.setFontSize(11); const splitText = doc.splitTextToSize(text, 190);
    let y = 30; for (let i = 0; i < splitText.length; i++) { if (y > 280) { doc.addPage(); y = 10; } doc.text(splitText[i], 10, y); y += 6; }
    doc.save(getSafeFilename("pdf"));
  } catch (e) { alert("Errore PDF: " + e.message); }
}

// --- HELPERS ---
function removeEmojis(text) { return text.replace(/\p{Extended_Pictographic}/gu, ''); }
function removeTimestamps(text) { return text.replace(/`?\[\d{1,2}:\d{2}(?::\d{2})?\]`?/g, '').replace(/  /g, ' ').trim(); }
function timeStrToSeconds(timeStr) { const parts = (timeStr || "0:0:0").replace(/[\[\]]/g, '').split(':').map(Number); if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2]; if (parts.length === 2) return parts[0] * 60 + parts[1]; return parts[0] || 0; }
function renderClickableTimestamps(text) { const output = $("aiOutput"); const escapedText = text.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\n/g, "<br>"); const timestampRegex = /\[(\d{1,2}:\d{2}(?::\d{2})?)\]/g; output.innerHTML = escapedText.replace(timestampRegex, (match, time) => `<a href="#" class="timestamp-link" data-time="${time}">${match}</a>`); }
async function handleTimestampClick(event) { if (event.target.classList.contains("timestamp-link")) { event.preventDefault(); const timeStr = event.target.dataset.time; const seconds = timeStrToSeconds(timeStr); const tabId = await getActiveTabId(); if(tabId) chrome.tabs.sendMessage(tabId, { type: "SEEK_VIDEO_TO", seconds }); } }
function checkMermaid(text) { $("btnAiViewMermaid").style.display = (text.includes("```mermaid") || text.includes("graph TD")) ? "inline-flex" : "none"; }
function openMermaidLive() { let text = $("aiOutput").innerText; text = removeTimestamps(text); const match = text.match(/```mermaid([\s\S]*?)```/); const code = match ? match[1].trim() : text; const b64 = btoa(unescape(encodeURIComponent(JSON.stringify({ code, mermaid: { theme: "default" } })))); chrome.tabs.create({ url: `https://mermaid.live/edit#base64:${b64}` }); }
function getSafeFilename(ext) { const title = $("aiOutput").dataset.metaTitle || "Video"; return `${title.replace(/[^a-z0-9]/gi, '_').substring(0, 50)}_Summary.${ext}`; }
function downloadBlob(content, mime, filename) { const blob = new Blob([content], { type: `${mime};charset=utf-8` }); const url = URL.createObjectURL(blob); chrome.downloads.download({ url, filename, saveAs: false }); }
function saveAiCleanTxt() { let raw = $("aiOutput").innerText; if(!raw) return; raw = removeTimestamps(raw); const clean = raw.replace(/\*\*(.*?)\*\*/g, '$1').replace(/\*(.*?)\*/g, '$1').replace(/^#+\s/gm, '').replace(/^\*\s/gm, '• ').replace(/\[(.*?)\]\(.*?\)/g, '$1'); downloadBlob(clean, "text/plain", getSafeFilename("txt")); }
function saveAiTelegramMd() { let raw = $("aiOutput").innerText; if(!raw) return; raw = removeTimestamps(raw); const tgMd = raw.replace(/\[(.*?)\]\(.*?\)/g, '$1'); downloadBlob(tgMd, "text/markdown", getSafeFilename("md")); }
function saveAiHtml() { let raw = $("aiOutput").innerText; if(!raw) return; raw = removeTimestamps(raw); let htmlBody = raw.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\*\*(.*?)\*\*/g, '<b>$1</b>').replace(/\*(.*?)\*/g, '<i>$1</i>').replace(/^#+\s(.*)$/gm, '<h2>$1</h2>').replace(/^\*\s(.*)$/gm, '<li>$1</li>').replace(/\n/g, '<br>'); const fullHtml = `<!DOCTYPE html><html lang="it"><head><meta charset="UTF-8"><style>body{background:#121212;color:#e0e0e0;font-family:sans-serif;padding:20px;line-height:1.6}b{color:#fff}h2{color:#4285f4;border-bottom:1px solid #333}li{margin-bottom:5px}</style></head><body>${htmlBody}</body></html>`; downloadBlob(fullHtml, "text/html", getSafeFilename("html")); }

// --- SECOND BRAIN ---
function saveToObsidian() {
  let content = $("aiOutput").innerText; if (!content) return;
  content = removeTimestamps(content);
  const fileName = generateUniqueTitle(window.currentMeta, "SUMMARY");
  const source = `Fonte: [${window.currentMeta.title}](${`https://www.youtube.com/watch?v=${window.currentMeta.videoId}`}) - **${window.currentMeta.channel}**`;
  const fullContent = `# ${window.currentMeta.title}\n\n${source}\n\n---\n\n${content}`;
  const url = `obsidian://new?name=${encodeURIComponent(fileName)}&content=${encodeURIComponent(fullContent)}`;
  chrome.tabs.create({ url });
}

// --- OBSIDIAN TRANSCRIPT (TXT+SRT) ---
function saveTranscriptToObsidian() {
  if (!window.currentTranscript) { alert("Nessuna trascrizione disponibile."); return; }
  
  const fileName = generateUniqueTitle(window.currentMeta, "TRANSCRIPT");
  const content = `# ${window.currentMeta.title}\n\n${window.currentTranscript}`;
  const url = `obsidian://new?name=${encodeURIComponent(fileName)}&content=${encodeURIComponent(content)}`;
  chrome.tabs.create({ url });
}



// --- NOTION API HELPER (STABLE) ---
async function notionFetch(url, token, options = {}) {
  const res = await fetch(url, { ...options, headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json", "Notion-Version": "2022-06-28", ...(options.headers || {}) } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.message || `HTTP ${res.status}`);
  return data;
}

async function findNotionPageByVideoId(dbId, token, videoId) {
  const q = { filter: { property: "youtube_video_id", rich_text: { equals: videoId } } };
  const data = await notionFetch(`https://api.notion.com/v1/databases/${dbId}/query`, token, { method: "POST", body: JSON.stringify(q) });
  return (data.results || [])[0]?.id || null;
}

// HELPER: Recupera i blocchi esistenti per evitare duplicati
async function getNotionPageBlocks(pageId, token) {
  const data = await notionFetch(`https://api.notion.com/v1/blocks/${pageId}/children?page_size=100`, token, { method: "GET" });
  return data.results || [];
}

async function executeNotionUpsert(meta, summaryText, transcriptTxt, transcriptSrt) {
  const token = $("notionToken").value; const dbId = $("notionDbId").value;
  if (!token || !dbId) { alert("Configura Notion nelle Impostazioni."); return; }

  const title = generateUniqueTitle(meta); // Usa il nuovo naming
  const youtubeUrl = `https://www.youtube.com/watch?v=${meta.videoId}`;

  // MAPPATURA COLONNE (Case Sensitive!)
  const props = {
    "title": { title: [{ text: { content: title } }] }, 
    "youtube_url": { url: youtubeUrl },
    "youtube_video_id": { rich_text: [{ text: { content: meta.videoId } }] },
    "source": { select: { name: "YouTube" } },
    "channel_name": { rich_text: [{ text: { content: meta.channel || "Sconosciuto" } }] },
    "personal_notes": { rich_text: [{ text: { content: $("notionNotes").value || "" } }] }
  };
  
  if (meta.publishDate) props["published_date"] = { date: { start: meta.publishDate } };
  if (meta.tags && meta.tags.length > 0) {
    props["tags"] = { multi_select: meta.tags.slice(0, 10).map(t => ({ name: t.replace(/,/g, '') })) };
  }
  
  const potential = $("notionPotential") ? $("notionPotential").checked : false;
  const importance = $("notionImportance") ? $("notionImportance").value : "3";
  const duration = meta.duration || "";

  props["potential_content"] = { checkbox: potential };
  props["importance"] = { select: { name: importance } };
  if (duration) props["yt_video_length"] = { rich_text: [{ text: { content: duration } }] };
  
  const thumbnailUrl = `https://img.youtube.com/vi/${meta.videoId}/maxresdefault.jpg`;
  props["thumbnails"] = { files: [{ name: "Thumbnail", type: "external", external: { url: thumbnailUrl } }] };

  try {
    const existingPageId = await findNotionPageByVideoId(dbId, token, meta.videoId);
    if (existingPageId) {
      await notionFetch(`https://api.notion.com/v1/pages/${existingPageId}`, token, { method: "PATCH", body: JSON.stringify({ properties: props }) });
      
      const existingBlocks = await getNotionPageBlocks(existingPageId, token);
      
      // APPEND TRASCRIZIONE TXT
      if (transcriptTxt) {
        const hasTxt = existingBlocks.some(b => b.type === 'toggle' && b.toggle.rich_text?.[0]?.text?.content?.includes("Trascrizione (Testo)"));
        if (!hasTxt) {
          const toggleBlocks = createTranscriptToggles("📜 Trascrizione (Testo)", transcriptTxt);
          await notionFetch(`https://api.notion.com/v1/blocks/${existingPageId}/children`, token, { method: "PATCH", body: JSON.stringify({ children: toggleBlocks }) });
        }
      }

      // APPEND TRASCRIZIONE SRT
      if (transcriptSrt) {
        const hasSrt = existingBlocks.some(b => b.type === 'toggle' && b.toggle.rich_text?.[0]?.text?.content?.includes("Trascrizione (SRT)"));
        if (!hasSrt) {
          const toggleBlocks = createTranscriptToggles("⏱️ Trascrizione (SRT)", transcriptSrt);
          await notionFetch(`https://api.notion.com/v1/blocks/${existingPageId}/children`, token, { method: "PATCH", body: JSON.stringify({ children: toggleBlocks }) });
        }
      }
      
      // APPEND RIASSUNTO
      if (summaryText) {
        const summaryBlocks = markdownToNotionBlocks(summaryText);
        summaryBlocks.unshift({ object: 'block', type: 'heading_2', heading_2: { rich_text: [{ text: { content: "Riassunto AI (Aggiornamento)" } }] } });
        await notionFetch(`https://api.notion.com/v1/blocks/${existingPageId}/children`, token, { method: "PATCH", body: JSON.stringify({ children: summaryBlocks }) });
      }

      alert("♻️ Aggiornato su Notion!");
    } else {
      const children = [];
      if (summaryText) {
        children.push({ object: 'block', type: 'heading_2', heading_2: { rich_text: [{ text: { content: "Riassunto AI" } }] } });
        children.push(...markdownToNotionBlocks(summaryText));
      }
      if (transcriptTxt) {
        children.push(...createTranscriptToggles("📜 Trascrizione (Testo)", transcriptTxt));
      }
      if (transcriptSrt) {
        children.push(...createTranscriptToggles("⏱️ Trascrizione (SRT)", transcriptSrt));
      }

      const body = { parent: { database_id: dbId }, properties: props, children: children };
      await notionFetch("https://api.notion.com/v1/pages", token, { method: "POST", body: JSON.stringify(body) });
      alert("✅ Creato su Notion!");
    }
  } catch (e) { alert(`❌ Errore Notion: ${e.message}`); }
}

// Helper per creare Toggle Block con testo lungo (Chunked)
function createTranscriptToggles(title, longText) {
  const textChunks = chunkTextToBlocks(longText);
  const toggleBlocks = [];
  const MAX_CHILDREN = 100;

  for (let i = 0; i < textChunks.length; i += MAX_CHILDREN) {
    const batch = textChunks.slice(i, i + MAX_CHILDREN);
    const partNum = Math.floor(i / MAX_CHILDREN) + 1;
    const toggleTitle = textChunks.length > MAX_CHILDREN ? `${title} (Parte ${partNum})` : title;

    toggleBlocks.push({
      object: "block",
      type: "toggle",
      toggle: {
        rich_text: [{ type: "text", text: { content: toggleTitle } }],
        children: batch
      }
    });
  }
  return toggleBlocks;
}

function chunkTextToBlocks(text) {
  const blocks = [];
  for (let i = 0; i < text.length; i += 2000) {
    blocks.push({
      object: "block",
      type: "paragraph",
      paragraph: { rich_text: [{ type: "text", text: { content: text.substring(i, i + 2000) } }] }
    });
  }
  return blocks;
}

// Wrapper functions
async function runSaveAiToNotion() {
  // FIX: Se mancano i dati, prova a recuperarli
  if (!window.currentMeta) {
    const success = await ensureVideoData();
    if (!success) { alert("Impossibile recuperare i dati del video."); return; }
  }
  
  const meta = window.currentMeta;
  let summary = $("aiOutput").innerText; 
  if (!summary) return; 
  summary = removeTimestamps(summary);
  
  const transcript = window.currentTranscript || null;
  await executeNotionUpsert(meta, summary, transcript, null);
}

async function runSaveTranscriptToNotion() {
  const btn = $("btnDlSaveNotion"); const originalText = btn.textContent; btn.textContent = "⏳ Scarico..."; btn.disabled = true;
  try {
    const tabId = await getActiveTabId(); await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }).catch(() => {});
    
    // Scarica TXT
    const respTxt = await chrome.tabs.sendMessage(tabId, { type: "BUILD_TRANSCRIPT_FOR_CURRENT", format: "txt", lang: $("lang").value });
    if (!respTxt?.ok) throw new Error(respTxt?.error || "Errore trascrizione TXT.");
    
    // Scarica SRT
    const respSrt = await chrome.tabs.sendMessage(tabId, { type: "BUILD_TRANSCRIPT_FOR_CURRENT", format: "srt", lang: $("lang").value });
    if (!respSrt?.ok) throw new Error(respSrt?.error || "Errore trascrizione SRT.");

    // Salva su Notion (Summary null, TXT, SRT)
    await executeNotionUpsert(respTxt.meta, null, respTxt.text, respSrt.text);
    
  } catch (e) { alert("Errore: " + e.message); } finally { btn.textContent = originalText; btn.disabled = false; }
}

// HELPER: RECUPERO DATI AL VOLO
async function ensureVideoData() {
  if (window.currentMeta && window.currentTranscript) return true;
  try {
    const tabId = await getActiveTabId();
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }).catch(() => {});
    const resp = await chrome.tabs.sendMessage(tabId, { type: "BUILD_TRANSCRIPT_FOR_CURRENT", format: "timed-txt", lang: $("lang").value });
    if (resp?.ok) {
      window.currentTranscript = resp.text;
      window.currentMeta = resp.meta;
      return true;
    }
  } catch (e) { console.error("Errore recupero dati video:", e); }
  return false;
}

// HELPER: NAMING CONVENTION (FIXED)
function generateUniqueTitle(meta, suffix = "") {
  const now = new Date();
  const d = String(now.getDate()).padStart(2, '0');
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const y = now.getFullYear();
  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  
  const timeStr = `${d}-${m}-${y} ${hh}.${mm}`; // Usa punto invece di due punti

  const safeChannel = (meta.channel || "Unknown").replace(/[\\/:*?"<>|]+/g, " ").trim();
  const safeTitle = (meta.title || "Video").replace(/[\\/:*?"<>|]+/g, " ").trim().substring(0, 50); 
  
  let name = `[${safeChannel}] ${safeTitle} (${timeStr})`;
  if (suffix) name += ` - ${suffix}`;
  
  return name.replace(/[\\/:*?"<>|]+/g, "-");
}

function markdownToNotionBlocks(text) {
  const lines = text.split('\n'); const blocks = [];
  for (const line of lines) {
    if (line.startsWith('## ')) blocks.push({ object: 'block', type: 'heading_2', heading_2: { rich_text: [{ type: 'text', text: { content: line.substring(3) } }] } });
    else if (line.startsWith('* ')) blocks.push({ object: 'block', type: 'bulleted_list_item', bulleted_list_item: { rich_text: [{ type: 'text', text: { content: line.substring(2) } }] } });
    else if (line.trim() !== '') blocks.push({ object: 'block', type: 'paragraph', paragraph: { rich_text: [{ type: 'text', text: { content: line } }] } });
  }
  return blocks;
}